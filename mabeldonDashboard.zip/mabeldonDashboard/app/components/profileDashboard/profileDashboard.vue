<template>

             <div class="row" id="profile-dashboard-data" >
                    <!--<div class="col col-lg-3 col-md-3 col-xs-12">
                      	<profile-card></profile-card>
                    </div>-->
                   <div class="col col-lg-3 col-md-3 col-xs-12">
                        <div class="card">
                            <h2 class="mcard-head">Contact Information</h2>
							<div class="mcard-body"><address-details ></address-details></div>
                        </div>
                    </div>
				 	<div class="col col-lg-6 col-md-6 col-xs-12">
                        <div class="card">
                            <h2 class="mcard-head">Networth</h2>
							<div class="mcard-body"><networth ></networth></div>

                        </div>
                    </div>
				 
				    <div class="col col-lg-3 col-md-3 col-xs-12">
                        <div class="card">
                            <h2 class="mcard-head">Risk Profile</h2>
							<div class="mcard-body" style="overflow: hidden;"><risk-profile></risk-profile></div>
                        </div>
                    </div>
				 
				   <div class="col col-lg-6 col-md-6 col-xs-12">
                        <div class="card">
                            <h2 class="mcard-head">My Family Members</h2>
                            <div class="mcard-body col-pad-10"><family-members></family-members></div>
                        </div>
                    </div>
                  <div class="col col-lg-3 col-md-3 col-xs-12">
                        <div class="card">
                            <h2 class="mcard-head">Accounts</h2>
							<div class="mcard-body"><bank-custody-accounts ></bank-custody-accounts></div>
            
                        </div>
                    </div>
				  <div class="col col-lg-3 col-md-3 col-xs-12">
                        <div class="card">
                            <h2 class="mcard-head">Investment Accounts</h2>
							<div class="mcard-body"><linked-accounts></linked-accounts></div>
                        </div>
                    </div>
				   <div class="col col-lg-3 col-md-3 col-xs-12">
                        <div class="card ">
                            <h2 class="mcard-head">Key Portfolio Alert</h2>
							<div class="mcard-body"><key-portfolio-alerts></key-portfolio-alerts></div>

                        </div>
                   </div>
			
				
              
                    <div class="col col-lg-6 col-md-6 col-xs-12">
                        <div class="card">
                            <h2 class="mcard-head">Activity</h2>
							<div class="mcard-body"><activities></activities></div>

                        </div>
                    </div>
				 
				   <div class="col col-lg-3 col-md-3 col-xs-12">
						<div class="card">
							<h2 class="mcard-head">Opportunity</h2>
							<div class="mcard-body"><opportunities></opportunities></div>

						</div>
				   </div>
                </div>
                <!-- profile dashboard -->
</template>

<script>
"use strict";
define(function (require, exports, module){

var address_details = require("vue!components/profileDashboard/address_details");
var bank_custody_accounts = require("vue!components/profileDashboard/bank_custody_accounts");
//var profile_card = require("vue!components/profileDashboard/profile_card");
var family_members = require("vue!components/profileDashboard/family_members");
var linked_accounts = require("vue!components/profileDashboard/linked_accounts");
var risk_profile = require("vue!components/profileDashboard/risk_profile");
var key_portfolio_alerts = require("vue!components/profileDashboard/key_portfolio_alerts");
var opportunities = require("vue!components/profileDashboard/opportunities");
var activities = require("vue!components/profileDashboard/activities");
var networth = require("vue!components/profileDashboard/networth");

    module.exports = {
        template: template,    
         components: {
			"address-details": address_details,
			"bank-custody-accounts": bank_custody_accounts,
//			"profile-card": profile_card,
			"family-members":family_members,
			"linked-accounts": linked_accounts,
			"risk-profile": risk_profile,
			"key-portfolio-alerts": key_portfolio_alerts,
			"opportunities": opportunities,
			"activities": activities,
			"networth": networth
        },
		data(){
			return {
				"tabData":{},
				"selected_account": "consolidated",
				"client_account_list":["consolidated"],
				"client_name": ""
			}
		},
		watch:{
			"selected_account": function(){
				this.setData(this.$parent.dashboardData);
			}	
		},
        methods: {
			
			setData(data){
				let _this=this;
				
				let dataKeys=Object.keys(data);
				this.$children.forEach((child)=>{
					let dataSrc=child.data_src;
					if(dataSrc.constructor===Array){
						var d={}
					   	dataSrc.forEach((dsrc)=>{
							d[dsrc]=data[dsrc];
						})
						child.data=d;
				   }
					else 
					if(dataKeys.includes(dataSrc)){
						child.data=data[dataSrc];
					}
					else{
						if(dataSrc=="risk_profile"){
						}
						child.data=data.client_accounts[_this.selected_account][dataSrc];
								
					}

				})
			},
			change(){
				this.setData(this.$parent.dashboardData)	
			},
            goBack () {
                window.history.length > 1
                ? this.$router.go(-1)
                : this.$router.push('/')
            }
        },
		mounted(){
			if(Object.keys(this.$parent.dashboardData).length)
				this.$parent.callSetData();

		}
    }
});

</script>