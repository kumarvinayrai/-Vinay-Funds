<template>
	<section class="clientDetail">
		<div class="" style="min-height: auto;">
			<div class="mcard-body">
				<div class="row">
				<div class="col-lg-1 col-md-1 col-xs-12 text-center">
					<img src="app/core/img/user_img.png">
				</div>
				<div class="col-lg-8 col-md-8 col-xs-12">
					<h4 class="mb-5 mt-5">{{client_name}}</h4>
					<div class="row extraDetail">
						<div class="col-lg-3 col-md-3 col-xs-6">
							<div class=" text-muted fnt12">ID</div>
							<div class="text-muted card-value">{{client_id}}</div>
						</div>
						<div class="col-lg-3 col-md-3 col-xs-6">
							<div class=" text-muted fnt12">RM</div>
							<div class="text-muted card-value">{{RM}}</div>
						</div>
						
					</div>
				</div>
			
			</div>
			</div>
		</div>
	</section>
</template>

<script>
"use strict";
define(function (require, exports, module){

    module.exports = {
        template: template   ,
		components: {
		},
		data(){
			return {
				"RM": "",
				"client_id": "",
				"client_name": ""
			}	
		},
		methods:{
			changeName(){
				this.$parent.customerName=this.client_name;
				this.$parent.fetchData();
			}
		},
		computed:{
		},
		mounted(){
		}
		
    }
});

</script>