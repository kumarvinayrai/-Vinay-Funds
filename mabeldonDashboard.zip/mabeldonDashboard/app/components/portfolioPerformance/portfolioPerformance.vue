<template>
		<section class="portfolioPerformance">
			<div class="row">
				<div class="col col-lg-12 col-sm-12 hide">
					<div class="card" style="min-height:auto;">
						<h2 class="mcard-head mcard-header" style="background: #191950">Portfolio Performance Breakdown</h2>
						<div class="mcard-body"><portfolioPerformanceBreakdown/></div>
					</div>
				</div>
			</div>
			<div class="row">
				<div class="col col-lg-4 col-md-4">
					<div class="card">
						<h2 class="mcard-head">Portfolio Performance </h2>
						<div class="mcard-body" id="portfolioPerformance"><portfolioPerformance/></div>
					</div>
				</div>
				<div class="col col-lg-8 col-md-8">
					<div class="card">
						<h2 class="mcard-head">Portfolio Appreciation <span class="fnt11 pull-right">In Millions</span></h2>
						<div class="mcard-body" id="portfolioAppreciation"><portfolioAppreciation/></div>
					</div>
				</div>
				
				<div class="col col-lg-12 col-md-12">
					<div class="card">
						<h2 class="mcard-head">Portfolio v/s Benchmark Performance </h2>
						<div class="mcard-body" id="portfolioBenchmarkPerformance"><portfolioBenchmarkPerformance/></div>
					</div>
				</div>
				
				<div class="col col-lg-6 col-md-12">
					<div class="card">
						<h2 class="mcard-head">Best Performance</h2>
						<div class="mcard-body" id="bestPerformance"><bestPerformance/></div>
					</div>
				</div>
				<div class="col col-lg-6 col-md-12">
					<div class="card">
						<h2 class="mcard-head">Worst Performance</h2>
						<div class="mcard-body" id="worstPerformance"><worstPerformance/></div>
					</div>
				</div>
			</div>
		</section>
</template>

<script>
"use strict";
define(function (require, exports, module){
	var portfolioBenchmarkPerformance = require("vue!components/portfolioPerformance/portfolio_benchmark_performance");
	var portfolioAppreciation = require("vue!components/portfolioPerformance/portfolio_appreciation");
	var portfolioPerformanceBreakdown = require("vue!components/portfolioPerformance/portfolio_performance_breakdown");
	var portfolioPerformance = require("vue!components/portfolioPerformance/portfolio_performance");
	var bestPerformance = require("vue!components/portfolioPerformance/best_performance");
	var worstPerformance = require("vue!components/portfolioPerformance/worst_performance");

    module.exports = {
        template: template,    
		components:{
			portfolioBenchmarkPerformance,
			portfolioAppreciation,
			portfolioPerformanceBreakdown,
			portfolioPerformance,
			bestPerformance,
			worstPerformance
		},
		data(){
			return {
				"data_source":[],
				"tabData":{},
				"selected_account": "consolidated",
				"client_account_list":["consolidated"],
				"client_name": ""
			}
		},
         computed: {
            username () {
                return this.$route.params.username
            }
        },
		watch:{
			"selected_account": function(){
				this.setData(this.$parent.dashboardData);
			}	
		},
            methods: {
			
			setData(data){
				let _this=this;
				
				let dataKeys=Object.keys(data);
				this.$children.forEach((child)=>{
					let dataSrc=child.data_src;
					if(dataSrc.constructor===Array){
						var d={}
					   	dataSrc.forEach((dsrc)=>{
							d[dsrc]=data[dsrc];
						})
						child.data=d;
				   }
					else 
					if(dataKeys.includes(dataSrc)){
						child.data=data[dataSrc];
					}
					else{
						
						child.data=data.client_accounts[_this.selected_account][dataSrc];
								
					}

				})
			},
			change(){
				this.setData(this.$parent.dashboardData)	
			},
            goBack () {
                window.history.length > 1
                ? this.$router.go(-1)
                : this.$router.push('/')
            }
        },
		mounted(){
			if(Object.keys(this.$parent.dashboardData).length)
				this.$parent.callSetData();

		}
    }
});

</script>