<template>
    <div class="graphContainer">
		 <div :id="containerid" ><!-- Plotly chart will be drawn inside this DIV --></div>
    </div>    
</template>

<script>
"use strict";
define(function (require, exports, module){
	var Plotly=require("plotly");
    module.exports = {
        template: template   ,
		data(){
			return {
				colors: ["#ef5030", "#55ace1", "#2c3d4f", "#f6ac2f"]
			}
		},
		props:["containerid","data_bucket"],
		watch:{
			"data_bucket"(){
				this.drawGraph();
			}	
		},
		methods:{
			drawGraph(){
				var data=[];
				this.data_bucket.data.forEach((dataObj,index) =>{
					var d={
						  type: 'bar',
						  x: [],
						  y: [],
						  name:'',
					  	  orientation: '',
						  marker: {
							color: '',
							width: 1
						  },
						};
					d.x=dataObj.x;
					d.y=dataObj.y;
					d.name=dataObj.name;
					d.orientation=dataObj.orientation;
					d.marker.color=this.colors[index] || '';
//					d.marker.width=dataObj.width | 1;
//					d.width=dataObj.width | 1;
					data.push(d);
				})
				
				var type="";
				var layout = {
					barmode: this.data_bucket.barmode,
						height: 320,
					margin: {
						l: this.data_bucket.marginleft | 50,
						r: 50,
						b: 10,
						t: 10,
						pad: 0
					  },
					showlegend: true,
					legend: {"orientation": "h"}
				};

				Plotly.newPlot(this.containerid, data, layout, {displayModeBar: false});
			}
		},
		mounted(){
			this.drawGraph();
		}
		
    }
});

</script>