/**
 * @license @product.name@ JS v@product.version@ (@product.date@)
 *
 * (c) 2016 Highsoft AS
 * Authors: Jon Arild Nygard
 *
 * License: www.highcharts.com/license
 */
'use strict';
import '../../modules/sunburst.src.js';
