<template>
    <div class="changePortfolioValue">
        
				<div class="row ">
					<div class="col-xs-4 col-sm-2"><div class="labecpv">Opening Balance</div><div class="text-dark">{{data.opening_balance || "-"}}</div></div>
					<div class="col-xs-4 col-sm-2"><div class="labecpv">Capital Inflow</div><div class="text-dark">{{data.capital_inflow || "-"}}</div></div>
					<div class="col-xs-4 col-sm-2"><div class="labecpv">Outflow / Withdrawal</div><div class="text-dark">{{data.outflow_withdrawal || "-"}}</div></div>
					<div class="col-xs-4 col-sm-2"><div class="labecpv">Unrealized gain (Loss)</div><div class="text-dark">{{data.unrealized_gain || "-"}}</div></div>
					<div class="col-xs-4 col-sm-2"><div class="labecpv">Realized Gain (Loss)</div><div class="text-dark">{{data.realized_gain || "-"}}</div></div>
					<div class="col-xs-4 col-sm-1"><div class="labecpv">Dividend </div><div class="text-dark">{{data.divident || "-"}}</div></div>
					<div class="col-xs-4 col-sm-1"><div class="labecpv">Coupons </div><div class="text-dark">{{data.coupons || "-"}}</div></div>
					<div class="col-xs-4 col-sm-2"><div class="labecpv">Other Income </div><div class="text-dark">{{data.other_income || "-"}}</div></div>
					<div class="col-xs-4 col-sm-2"><div class="labecpv">Management Fees</div><div class="text-dark">{{data.management_fees || "-"}}</div></div>
					<div class="col-xs-4 col-sm-2"><div class="labecpv">Brokerage</div><div class="text-dark">{{data.brokerage || "-"}}</div></div>
					<div class="col-xs-4 col-sm-2"><div class="labecpv">Security Transaction Tax</div><div class="text-dark">{{data.security_transaction_tax || "-"}}</div></div>
					<div class="col-xs-4 col-sm-2"><div class="labecpv">Custodian Fees</div><div class="text-dark">{{data.custodian_fees || "-"}}</div></div>
					<div class="col-xs-4 col-sm-2"><div class="labecpv">Other Expenses</div><div class="text-dark">{{data.other_expenses || "-"}}</div></div>
				
					
				</div>
			
    </div>    
</template>

<script>
"use strict";
define(function (require, exports, module){
    module.exports = {
        template: template   ,
		data(){
			return {
				"data_src" : "change_in_portfolio_value",
				"data": {}
			}	
		},
		methods:{
		
		},
		mounted(){

		}
		
    }
});

</script>