<template>
    <div class="addressDetails">
        <div class="row" v-if="Object.keys(data).length">
			<div class="col-lg-12 col-md-12 col-xs-12">
				<div class=" text-muted fnt-14">{{getClientName}}</div>
				
				<div class="emailId"><i class="fa fa-envelope text-muted"></i> &nbsp; <a :href="data.emailId">{{data.email}}</a></div>
				<div><i class="fa fa-mobile"></i> &nbsp; {{data.mobile}}</div>

				<div class="address">
					<div class="fnt-weight410">Communication/Correspondance Address</div>
					<div class="addDetail">
						<div>{{data.address}},</div>
						<div>{{data.city}},</div>
						<div>{{data.country}}</div>
					</div>
				</div>
			</div>
			
			
		</div>
		
    </div>    
</template>

<script>
"use strict";
define(function (require, exports, module){
    module.exports = {
        template: template   ,
		data(){
			return {
				"data_src" : "address_details",
				"data": {}
			}	
		},
		methods:{
		
		},
		computed:{
			
			getClientName(){
				return this.$parent.client_name;
			}
		},
		mounted(){

		}
		
    }
});

</script>