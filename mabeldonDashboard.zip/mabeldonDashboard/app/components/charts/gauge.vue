<template>
		<div :id="id" style="height: 200px;"><!-- Plotly chart will be drawn inside this DIV --></div>
</template>

<script>
"use strict";
define(function (require, exports, module){
	var Plotly=require("plotly");
    module.exports = {
        template: template   ,
		props:["id","data"],
		data(){
			return {
				data1:{
					labelText: ['Highly Aggressive', 'Aggressive', 'Moderate', 'Conservative',
							'Risk Averse'],
					labels:['151-180', '121-150', '91-120', '1', '7-15', '0-6'],
					value: 150
				}
			}	
		},
		watch:{
			"data": function(){
				this.draw();
//				this.draw1();

			}
		},
		methods:{
			draw1(){
				var labelText=['Risk Averse', 'Conservative', 'Moderate', 'Aggressive ','Highly Aggressive'];
				var labels=['0-6', '7-15', '16-25','26-34', '35-40'];
				var highestRange= parseInt(labels[labels.length-1].split("-")[1]);
				var denominator= labels.length;
				var numerator=(denominator-1)*10;
				var totalNum=numerator*denominator;
				var multiplyFactor=totalNum/highestRange;
				var values=[];
				labels.forEach((label)=>{
					var lab=label.split("-");
//					var val=(parseInt(lab[1])-parseInt(lab[0]))*multiplyFactor;
					var val=(parseInt(lab[1])-parseInt(lab[0])+1);
//					values.push(val/denominator);
					values.push(val);
				})
				values=values.reverse();	
				values.push(numerator);
				labelText=labelText.reverse();
				labelText.push("");
				labels=labels.reverse();
				labels.push("");
				console.log(labelText,"==",labels,"==",values)
				
				/* gauge chart code*/
				// Enter a speed between 0 and 180
				var level = 175;

				// Trig to calc meter point
				var degrees = 180 - level,
					 radius = .5;
				var radians = degrees * Math.PI / 180;
				var x = radius * Math.cos(radians);
				var y = radius * Math.sin(radians);

				// Path: may have to change to create a better triangle
				var mainPath = 'M -.0 -0.025 L .0 0.025 L ',
					 pathX = String(x),
					 space = ' ',
					 pathY = String(y),
					 pathEnd = ' Z';
				var path = mainPath.concat(pathX,space,pathY,pathEnd);

				var data = [{ type: 'scatter',
				   x: [0], y:[0],
					marker: {size: 10, color:'013856'},
					showlegend: false,
					name: 'speed',
					text: level,
					hoverinfo: 'text+name'},
				  { values: values,
				  rotation: 90,
				  text: labelText,
				  textinfo: 'text',
				  textposition:'inside',	  
				  marker: {colors:['#EF5030', '#fd856d',
										 '#F6AC2F', '#b8d070',
										 '#5FB667',
										 'rgba(255, 255, 255, 0)']},
				  labels: labels,
				  hoverinfo: 'label',
				  hole: .5,
				  type: 'pie',
				  showlegend: false
				}];

				var layout = {
				  shapes:[{
					  type: 'path',
					  path: path,
					  fillcolor: '850000',
					  line: {
						color: '850000'
					  }
					}],
//				  title: '<span style="margin-top: 10px;"><b>Risk-O-meter</b><br><span>7 Aug</span></span>',
				  height: 300,
					 margin: {
					l: 0,
					r: 0,
					b: 0,
					t: 10,
					pad: 4
				  },
				  xaxis: {zeroline:false, showticklabels:false,
							 showgrid: false, range: [-1, 1], tickangle:"horizontal"},
				  yaxis: {zeroline:false, showticklabels:false,
							 showgrid: false, range: [-1, 1],  tickangle:"horizontal"}
				};

				Plotly.newPlot(this.id, data, layout,{displayModeBar: false});
			},
			draw(){
				var labelT=this.data1.labelText;
				var labelText=[];
				// Enter a speed between 0 and 180
//				var level = this.value;
				var level = this.data.value | 0;
				labelT.forEach((label)=>{
					var labelTemp="";
					if(/\s/g.test(label)){
						var splitL=label.split(" ");
						splitL.forEach((subT)=>{
							labelTemp+=subT+"<br>"
						})
					}
					else
						labelTemp=label;
					labelText.push("<span style='font-size: 9px !important; color: white;'>"+labelTemp+"</span>")
					
				});
				
				var labels =this.data1.labels;
				var denominator=labelText.length;
				var numerator=(denominator-1)*10;
//				var values=[];
				var values=[];
				labelText.forEach(()=>{
					values.push(numerator/denominator);
				});
				
				labelText.push("");
				labels.push("");
				values.push(numerator);
			
								

				// Trig to calc meter point
				var degrees = 180 - level,
					 radius = .5;
				var radians = degrees * Math.PI / 180;
				var x = radius * Math.cos(radians);
				var y = radius * Math.sin(radians);

				// Path: may have to change to create a better triangle
				var mainPath = 'M -.0 -0.025 L .0 0.025 L ',
					 pathX = String(x),
					 space = ' ',
					 pathY = String(y),
					 pathEnd = ' Z';
				var path = mainPath.concat(pathX,space,pathY,pathEnd);

				var data = [{ type: 'scatter',
				   x: [0], y:[0],
					marker: {size: 10, color:'013856'},
					showlegend: false,
					name: 'speed',
					text: level,
					hoverinfo: 'text+name'},
				  { values: values,
				  rotation: 90,
				  text: labelText,
				  textinfo: 'text',
				  textposition:'inside',	  
				  marker: {colors:['#EF5030', '#fd856d',
										 '#F6AC2F', '#b8d070',
										 '#5FB667',
										 'rgba(255, 255, 255, 0)']},
				  labels: labels,
				  hoverinfo: 'label',
				  hole: .5,
				  type: 'pie',
				  showlegend: false
				}];

				var layout = {
				  shapes:[{
					  type: 'path',
					  path: path,
					  fillcolor: '850000',
					  line: {
						color: '850000'
					  }
					}],
//				  title: '<span style="margin-top: 10px;"><b>Risk-O-meter</b><br><span>7 Aug</span></span>',
				  height: 300,
					 margin: {
					l: 0,
					r: 0,
					b: 0,
					t: 10,
					pad: 4
				  },
				  xaxis: {zeroline:false, showticklabels:false,
							 showgrid: false, range: [-1, 1], tickangle:"horizontal"},
				  yaxis: {zeroline:false, showticklabels:false,
							 showgrid: false, range: [-1, 1],  tickangle:"horizontal"}
				};

				Plotly.newPlot(this.id, data, layout,{displayModeBar: false});
			}
		},
		computed:{
		},
		mounted(){
		}
		
    }
});

</script>