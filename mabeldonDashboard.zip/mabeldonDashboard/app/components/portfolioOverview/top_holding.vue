<template>
    <div class="topHolding">
		<div class="custom-panel row" v-for="holding in data">             
			<div class="col-xs-12 col-sm-12 col-md-12 col-lg-12 text-primary">
				{{holding.security_name}}
			</div> 
			<div class="col-xs-6 col-sm-6 col-md-6 col-lg-8 bg-badge">
				<div class="text-muted fnt18 ">{{holding.pcy}} {{holding.holding_value}} </div>
			</div>
			<div class="col-xs-6 col-sm-6 col-md-6 col-lg-4 text-right">
				<span class="">{{holding.allocation}}%</span>&nbsp;
				
			</div> 
		</div> 
		
    </div>    
</template>

<script>
"use strict";
define(function (require, exports, module){

    module.exports = {
        template: template   ,
		components:{
		},
		data(){
			return {
				"data_src" : "top_5_holding",
				"data": []
			}
		},
		methods:{
		
		},
		mounted(){

		}
		
    }
});

</script>