<template>
    <div class="portfolioPerformanceBreakdown">
		<div class="row">
			<div class="col-xs-12 col-sm-6 col-md-6 col-lg-3 padding-left-none padding-right-none">
				<div class="portfolio-card-layout">
					<div class="col-xs-3 col-sm-6 col-md-6 col-lg-6"><h5 class="text-primary lead ">Account1</h5></div>
					<div class="col-xs-9 col-sm-6 col-md-6 col-lg-6"><div class="text-contaier"><span class="label-danger">Aggressive</span></div></div>
					<div class="col-sm-12 col-md-12 col-lg-12 margin-bottom-md"><div class="text-info txt-lead lead">MSCI World Equity Index</div></div>
					<div class="col-xs-9 col-sm-7 col-md-7 col-lg-8 margin-bottom-md"><div class="text-dark text-uppercase card-xs-fnt-text">capital invested</div><div class="text-muted text-lower">(Net of Inflows and Outflow)</div></div>
					<div class="col-xs-3 col-sm-5 col-md-5 col-lg-4 margin-bottom-md"><div class="text-primary text-right lead card-sm-fnt-text">$&nbsp;1500</div></div>
					<div class="col-xs-9 col-sm-7 col-md-7 col-lg-8"><span class="text-dark text-uppercase card-xs-fnt-text">Portfolio Value</span></div>
					<div class="col-xs-3 col-sm-5 col-md-5 col-lg-4"><div class="text-warning text-right lead card-sm-fnt-text">$&nbsp;1500</div></div>
					<div class="col-xs-9 col-sm-7 col-md-7 col-lg-8 margin-bottom-md"><span class="text-dark text-uppercase card-xs-fnt-text">BENCHMARK Value</span><div class="text-muted text-lower">(if invested in benchmark)</div></div>
					<div class="col-xs-3 col-sm-5 col-md-5 col-lg-4 margin-bottom-md"><div class="text-info text-right lead card-sm-fnt-text">$&nbsp;1500</div></div>
					<div class="col-xs-5 col-sm-6 col-md-4 col-md4 col-lg-5 margin-bottom-md"><span class="text-dark text-uppercase card-xs-fnt-text">portfolio Growth</span>
						<div class="text-muted text-lower text-fnt-sm">(Absolute)<span class="text-primary sx-fnt-text">2.5%</span></div>
					</div>
					<div class=" col-xs-7 col-sm-6 col-md-8 col-md8 col-lg-7 margin-bottom-md text-right">
						<span class=" text-primary lead card-sm-fnt-text pull-right">19%</span>
						<span class="lead lead-xs text-muted pull-right">Relative to Benchmark</span>
					</div>
				</div> 
			</div> 
			
			<div class="col-xs-12 col-sm-6 col-md-6 col-lg-3 padding-left-none padding-right-none">
				<div class="portfolio-card-layout">
					<div class="col-xs-3 col-sm-6 col-md-6 col-lg-6"><h5 class="text-primary lead ">Account1</h5></div>
					<div class="col-xs-9 col-sm-6 col-md-6 col-lg-6"><div class="text-contaier"><span class="label-danger">Aggressive</span></div></div>
					<div class="col-sm-12 col-md-12 col-lg-12 margin-bottom-md"><div class="text-info txt-lead lead">MSCI World Equity Index</div></div>
					<div class="col-xs-9 col-sm-7 col-md-7 col-lg-8 margin-bottom-md"><div class="text-dark text-uppercase card-xs-fnt-text">capital invested</div><div class="text-muted text-lower">(Net of Inflows and Outflow)</div></div>
					<div class="col-xs-3 col-sm-5 col-md-5 col-lg-4 margin-bottom-md"><div class="text-primary text-right lead card-sm-fnt-text">$&nbsp;1500</div></div>
					<div class="col-xs-9 col-sm-7 col-md-7 col-lg-8"><span class="text-dark text-uppercase card-xs-fnt-text">Portfolio Value</span></div>
					<div class="col-xs-3 col-sm-5 col-md-5 col-lg-4"><div class="text-warning text-right lead card-sm-fnt-text">$&nbsp;1500</div></div>
					<div class="col-xs-9 col-sm-7 col-md-7 col-lg-8 margin-bottom-md"><span class="text-dark text-uppercase card-xs-fnt-text">BENCHMARK Value</span><div class="text-muted text-lower">(if invested in benchmark)</div></div>
					<div class="col-xs-3 col-sm-5 col-md-5 col-lg-4 margin-bottom-md"><div class="text-info text-right lead card-sm-fnt-text">$&nbsp;1500</div></div>
					<div class="col-xs-5 col-sm-6 col-md-4 col-md4 col-lg-5 margin-bottom-md"><span class="text-dark text-uppercase card-xs-fnt-text">portfolio Growth</span>
						<div class="text-muted text-lower text-fnt-sm">(Absolute)<span class="text-primary sx-fnt-text">2.5%</span></div>
					</div>
					<div class=" col-xs-7 col-sm-6 col-md-8 col-md8 col-lg-7 margin-bottom-md text-right">
						<span class=" text-primary lead card-sm-fnt-text pull-right">19%</span>
						<span class="lead lead-xs text-muted pull-right">Relative to Benchmark</span>
					</div>
				</div> 
			</div> 
			
				<div class="col-xs-12 col-sm-6 col-md-6 col-lg-3 padding-left-none padding-right-none">
				<div class="portfolio-card-layout">
					<div class="col-xs-3 col-sm-6 col-md-6 col-lg-6"><h5 class="text-primary lead ">Account1</h5></div>
					<div class="col-xs-9 col-sm-6 col-md-6 col-lg-6"><div class="text-contaier"><span class="label-danger">Aggressive</span></div></div>
					<div class="col-sm-12 col-md-12 col-lg-12 margin-bottom-md"><div class="text-info txt-lead lead">MSCI World Equity Index</div></div>
					<div class="col-xs-9 col-sm-7 col-md-7 col-lg-8 margin-bottom-md"><div class="text-dark text-uppercase card-xs-fnt-text">capital invested</div><div class="text-muted text-lower">(Net of Inflows and Outflow)</div></div>
					<div class="col-xs-3 col-sm-5 col-md-5 col-lg-4 margin-bottom-md"><div class="text-primary text-right lead card-sm-fnt-text">$&nbsp;1500</div></div>
					<div class="col-xs-9 col-sm-7 col-md-7 col-lg-8"><span class="text-dark text-uppercase card-xs-fnt-text">Portfolio Value</span></div>
					<div class="col-xs-3 col-sm-5 col-md-5 col-lg-4"><div class="text-warning text-right lead card-sm-fnt-text">$&nbsp;1500</div></div>
					<div class="col-xs-9 col-sm-7 col-md-7 col-lg-8 margin-bottom-md"><span class="text-dark text-uppercase card-xs-fnt-text">BENCHMARK Value</span><div class="text-muted text-lower">(if invested in benchmark)</div></div>
					<div class="col-xs-3 col-sm-5 col-md-5 col-lg-4 margin-bottom-md"><div class="text-info text-right lead card-sm-fnt-text">$&nbsp;1500</div></div>
					<div class="col-xs-5 col-sm-6 col-md-4 col-md4 col-lg-5 margin-bottom-md"><span class="text-dark text-uppercase card-xs-fnt-text">portfolio Growth</span>
						<div class="text-muted text-lower text-fnt-sm">(Absolute)<span class="text-primary sx-fnt-text">2.5%</span></div>
					</div>
					<div class=" col-xs-7 col-sm-6 col-md-8 col-md8 col-lg-7 margin-bottom-md text-right">
						<span class=" text-primary lead card-sm-fnt-text pull-right">19%</span>
						<span class="lead lead-xs text-muted pull-right">Relative to Benchmark</span>
					</div>
				</div> 
			</div> 
			
				<div class="col-xs-12 col-sm-6 col-md-6 col-lg-3 padding-left-none padding-right-none">
				<div class="portfolio-card-layout">
					<div class="col-xs-3 col-sm-6 col-md-6 col-lg-6"><h5 class="text-primary lead ">Account1</h5></div>
					<div class="col-xs-9 col-sm-6 col-md-6 col-lg-6"><div class="text-contaier"><span class="label-danger">Aggressive</span></div></div>
					<div class="col-sm-12 col-md-12 col-lg-12 margin-bottom-md"><div class="text-info txt-lead lead">MSCI World Equity Index</div></div>
					<div class="col-xs-9 col-sm-7 col-md-7 col-lg-8 margin-bottom-md"><div class="text-dark text-uppercase card-xs-fnt-text">capital invested</div><div class="text-muted text-lower">(Net of Inflows and Outflow)</div></div>
					<div class="col-xs-3 col-sm-5 col-md-5 col-lg-4 margin-bottom-md"><div class="text-primary text-right lead card-sm-fnt-text">$&nbsp;1500</div></div>
					<div class="col-xs-9 col-sm-7 col-md-7 col-lg-8"><span class="text-dark text-uppercase card-xs-fnt-text">Portfolio Value</span></div>
					<div class="col-xs-3 col-sm-5 col-md-5 col-lg-4"><div class="text-warning text-right lead card-sm-fnt-text">$&nbsp;1500</div></div>
					<div class="col-xs-9 col-sm-7 col-md-7 col-lg-8 margin-bottom-md"><span class="text-dark text-uppercase card-xs-fnt-text">BENCHMARK Value</span><div class="text-muted text-lower">(if invested in benchmark)</div></div>
					<div class="col-xs-3 col-sm-5 col-md-5 col-lg-4 margin-bottom-md"><div class="text-info text-right lead card-sm-fnt-text">$&nbsp;1500</div></div>
					<div class="col-xs-5 col-sm-6 col-md-4 col-md4 col-lg-5 margin-bottom-md"><span class="text-dark text-uppercase card-xs-fnt-text">portfolio Growth</span>
						<div class="text-muted text-lower text-fnt-sm">(Absolute)<span class="text-primary sx-fnt-text">2.5%</span></div>
					</div>
					<div class=" col-xs-7 col-sm-6 col-md-8 col-md8 col-lg-7 margin-bottom-md text-right">
						<span class=" text-primary lead card-sm-fnt-text pull-right">19%</span>
						<span class="lead lead-xs text-muted pull-right">Relative to Benchmark</span>
					</div>
				</div> 
			</div> 
			
						

		</div>
		
		<div class="viewMore">
			<div class="text-right">
				<a href="" class="btn btn_default text-primary lead fnt13" data-toggle="modal" data-target="#performanceBreakdownModal">View More..</a>
			</div>

			<!-- Modal -->
			<div class="modal fade" id="performanceBreakdownModal" tabindex="-1" role="dialog" aria-labelledby="myModalLabel">
			  <div class="modal-dialog" role="document">
				<div class="modal-content">
				  <div class="modal-header">
					<button type="button" class="close" data-dismiss="modal" aria-label="Close"><span aria-hidden="true">&times;</span></button>
					<h4 class="modal-title" id="myModalLabel">Portfolio Performance Breakdown</h4>
				  </div>
				  <div class="modal-body">
					<div class="row">
						<div class="col-lg-12">
							<div class="portfolio-card-layout">
								<div class="col-xs-3 col-sm-6 col-md-6 col-lg-6"><h5 class="text-primary lead ">Account1</h5></div>
								<div class="col-xs-9 col-sm-6 col-md-6 col-lg-6"><div class="text-contaier"><span class="label-danger">Aggressive</span></div></div>
								<div class="col-sm-12 col-md-12 col-lg-12 margin-bottom-md"><div class="text-info txt-lead lead">MSCI World Equity Index</div></div>
								<div class="col-xs-9 col-sm-7 col-md-7 col-lg-8 margin-bottom-md"><div class="text-dark text-uppercase card-xs-fnt-text">capital invested</div><div class="text-muted text-lower">(Net of Inflows and Outflow)</div></div>
								<div class="col-xs-3 col-sm-5 col-md-5 col-lg-4 margin-bottom-md"><div class="text-primary text-right lead card-sm-fnt-text">$&nbsp;1500</div></div>
								<div class="col-xs-9 col-sm-7 col-md-7 col-lg-8"><span class="text-dark text-uppercase card-xs-fnt-text">Portfolio Value</span></div>
								<div class="col-xs-3 col-sm-5 col-md-5 col-lg-4"><div class="text-warning text-right lead card-sm-fnt-text">$&nbsp;1500</div></div>
								<div class="col-xs-9 col-sm-7 col-md-7 col-lg-8 margin-bottom-md"><span class="text-dark text-uppercase card-xs-fnt-text">BENCHMARK Value</span><div class="text-muted text-lower">(if invested in benchmark)</div></div>
								<div class="col-xs-3 col-sm-5 col-md-5 col-lg-4 margin-bottom-md"><div class="text-info text-right lead card-sm-fnt-text">$&nbsp;1500</div></div>
								<div class="col-xs-5 col-sm-6 col-md-4 col-md4 col-lg-5 margin-bottom-md"><span class="text-dark text-uppercase card-xs-fnt-text">portfolio Growth</span>
									<div class="text-muted text-lower text-fnt-sm">(Absolute)<span class="text-primary sx-fnt-text">2.5%</span></div>
								</div>
								<div class=" col-xs-7 col-sm-6 col-md-8 col-md8 col-lg-7 margin-bottom-md text-right">
									<span class=" text-primary lead card-sm-fnt-text pull-right">19%</span>
									<span class="lead lead-xs text-muted pull-right">Relative to Benchmark</span>
								</div>
							</div> 
						</div>
					</div> 

				  </div>
				  <div class="modal-footer">
					<button type="button" class="btn btn_default text-primary fnt13" data-dismiss="modal">Close</button>
				  </div>
				</div>
			  </div>
			</div>

		</div>
		
    </div>    
</template>

<script>
"use strict";
define(function (require, exports, module){

    module.exports = {
        template: template   ,
		components:{
		},
		data(){
			return {
				"data_src" : "activities",
				"data": []
			}
		},
		methods:{
		
		},
		mounted(){

		}
		
    }
});

</script>