<template>
		<section class="portfolioHoldings">
		<div>

			  <!-- Nav tabs -->
			  <ul class="nav nav-tabs" role="tablist">
				<li role="presentation" class="active"><a href="#investmentRecommendation" aria-controls="investmentRecommendation" role="tab" data-toggle="tab">INVESTMENT RECOMMENDATION</a></li>
				<li role="presentation"><a href="#rebalancePortfolio" aria-controls="rebalancePortfolio" role="tab" data-toggle="tab">REBALANCE PORTFOLIO</a></li>
				<li role="presentation"><a href="#addSecurity" aria-controls="addSecurity" role="tab" data-toggle="tab">ADD A SECURITY</a></li>
			  </ul>

			  <!-- Tab panes -->
			  <div class="tab-content">
				<div role="tabpanel" class="tab-pane active" id="investmentRecommendation"><br><br><investmentRecommendation/></div>
				<div role="tabpanel" class="tab-pane" id="rebalancePortfolio">...</div>
				<div role="tabpanel" class="tab-pane" id="addSecurity">...</div>
			  </div>

			</div>
		</section>
</template>

<script>
"use strict";
define(function (require, exports, module){
	var investmentRecommendation = require("vue!components/portfolioHoldings/investment_recommendation");
	
    module.exports = {
        template: template,    
		components:{
			investmentRecommendation
		},
		data(){
			return {
				"data_source":[],
				"tabData":{},
				"selected_account": "consolidated",
				"client_account_list":["consolidated"],
				"client_name": ""
			}
		},
         computed: {
            username () {
                return this.$route.params.username
            }
        },
		watch:{
			"selected_account": function(){
				this.setData(this.$parent.dashboardData);
			}	
		},
            methods: {
			
			setData(data){
				let _this=this;
				
				let dataKeys=Object.keys(data);
				this.$children.forEach((child)=>{
					let dataSrc=child.data_src;
					if(dataSrc.constructor===Array){
						var d={}
					   	dataSrc.forEach((dsrc)=>{
							d[dsrc]=data[dsrc];
						})
						child.data=d;
				   }
					else 
					if(dataKeys.includes(dataSrc)){
						child.data=data[dataSrc];
					}
					else{
						
						child.data=data.client_accounts[_this.selected_account][dataSrc];
								
					}

				})
			},
			change(){
				this.setData(this.$parent.dashboardData)	
			},
            goBack () {
                window.history.length > 1
                ? this.$router.go(-1)
                : this.$router.push('/')
            }
        },
		mounted(){
			if(Object.keys(this.$parent.dashboardData).length)
				this.$parent.callSetData();

		}
    }
});

</script>