<template>
	<section class="keyPortfolioAlerts">
		<div class="row" v-for="alert in data.slice(0,4)">
			<div class="col-sm-3 col-xs-2 border-style text-center">
				<span class="text-light">{{getDate(alert.due_date,"month")}}</span><br>
				<span class="text-muted fnt19">{{getDate(alert.due_date,"day")}} </span>
			</div>
			<div class="col-sm-9 col-xs-10 ">
				<div class="text-muted  fnt-14">{{alert.security_name || alert.document_name}}</div>
				<div class="text-warning fnt18  "><span class="currency" v-if="alert.amount">{{alert.currency}}</span> &nbsp;{{alert.amount}}  <label class="label label-warning pull-right">{{alert.alert_type}}</label></div>
			</div>
		</div>
		
		<div class="viewMore" v-if="data.length>3">
			<span class="pull-right">
				<a href="" class="btn btn_default text-primary lead fnt13" data-toggle="modal" data-target="#keyPortfolioAlertsModal">View More..</a>
			</span>

			<!-- Modal -->
			<div class="modal fade" id="keyPortfolioAlertsModal" tabindex="-1" role="dialog" aria-labelledby="myModalLabel">
			  <div class="modal-dialog" role="document">
				<div class="modal-content">
				  <div class="modal-header">
					<button type="button" class="close" data-dismiss="modal" aria-label="Close"><span aria-hidden="true">&times;</span></button>
					<h4 class="modal-title" id="myModalLabel">Key Portfolio Alerts</h4>
				  </div>
				  <div class="modal-body">
					<div class="row" v-for="alert in data">
						<div class="col-sm-2 col-xs-2 border-style text-center">
							<span class="text-light">{{getDate(alert.due_date,"month")}}</span><br>
							<span class="text-muted fnt19">{{getDate(alert.due_date,"day")}} </span>
						</div>
						<div class="col-sm-10 col-xs-10 ">
							<div class="text-muted fnt-14">{{alert.security_name || alert.document_name}}</div>
							<div class="text-warning fnt18  "><span class="currency" v-if="alert.amount">{{alert.currency}}</span> &nbsp;{{alert.amount}}  <label class="label label-warning pull-right">{{alert.alert_type}}</label></div>
						</div>
					</div>
				  </div>
				  <div class="modal-footer">
					<button type="button" class="btn btn_default text-primary fnt13" data-dismiss="modal">Close</button>
				  </div>
				</div>
			  </div>
			</div>

		</div>
		
	</section>
</template>

<script>
"use strict";
define(function (require, exports, module){

    module.exports = {
        template: template   ,
		data(){
			return {
				"data_src" : "key_portfolio_alerts",
				"data": []
			}	
		},
		methods:{
			getDate(date,part){
				var dateO=new Date(date);
				if(part=="day"){
					return dateO.getDate();
				}
				else{
					var months=["JAN", "FEB", "MAR", "APR", "MAY", "JUN","JUL", "AUG", "SEP", "OCT", "NOV", "DEC"];
					return months[dateO.getMonth()];
				}
			}
		},
		computed:{
		},
		mounted(){
		}
		
    }
});

</script>