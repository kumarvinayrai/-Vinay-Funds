<template>
	  <section class="user-hierarchy"> 
                     
        <div class="user-container">
                <div class="user-wrapper">
                    <!-- Key component -->
                    <div class="user-item">
                        <div class="user-item-parent">
                                <div class="tree-card"> 
									<div class="img-round-parent">
											<img class="img-circle-parent" src="app/core/img/child1.png" alt="">
									</div>
									<div class="parent-user-detail hidden-xs">
										<div class="text-color">{{getCustomerName}}</div> 
										<div class="fnt12 txt-align-left">Self</div>
									</div>   
								</div>
                        </div>
        
                        <div class="user-item-children">
							<div class="user-item-child" v-for="child in data.slice(0,2)" style="padding: 0 120px;">
								<div class="tree-card"> 
									<div class="img-round-male-child">
										<img class="img-circle-male-child" src="app/core/img/child1.png" alt="">
										 <div class="hidden-xs child-detail" style="width: 150px;">
												<div class="text-primary fnt12 " >{{child.family_members}}</div> 
												<div class="fnt12 ">{{child.risk_profile}}</div>
												<div class="text-muted fnt12 ">{{child.investment_value}}({{child.currency}})</div>
										</div>   
									</div>
								</div>
							</div>
        
               
                        </div>
        
                    </div>
        
                </div>
		</div>
		<a href="#" class="pull-right tree-more"><label class="label label-primary">View More</label></a>
	  </section>      
</template>

<script>
"use strict";
define(function (require, exports, module){
    module.exports = {
        template: template   ,
		data(){
			return {
				"data_src" : "family_members",
				"data": []
			}	
		},
		methods:{
		
		},
		computed:{
			getCustomerName(){
				return this.$parent.client_name;
			}
			
		},
		mounted(){

		}
		
    }
});

</script>