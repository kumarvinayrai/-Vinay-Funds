<template>
	<div class="bestPerformance">
		<div class="responsive-table"> 
		
			<table class="table table-striped">
				<thead>
					<tr class="worst-performance-bgcolor">
						<th><span>Security</span></th>
						<th align="center">Absolute</th>
						<th><span>XIRR</span></th>
					</tr>
				</thead>
				<tbody> 
					<tr class="data-row trim-info" v-for="security in data">
						<td><span>{{security.security_name}}</span></td>  
						<td><span>{{security.absolute_return}}%</span></td>
						<td><span>{{security.xirr_return}}%</span></td>
					</tr>
				
				</tbody>
			</table>
		</div>  
	
	</div>
</template>

<script>
"use strict";
define(function (require, exports, module){

    module.exports = {
        template: template   ,
		components:{
		},
		data(){
			return {
				"data_src" : "worst_performance",
				"data": []
			}
		},
		methods:{
		
		},
		mounted(){

		}
		
    }
});

</script>