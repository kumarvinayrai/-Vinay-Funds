<template>
    <div class="portfolioAppreciation" v-if="Object.keys(data).length">
  		<lineChart containerid="portfolioAppreciationGraph" :data_bucket="graphData"  />
    </div>    
</template>

<script>
"use strict";
define(function (require, exports, module){
	var lineChart = require("vue!components/charts/line_chart");

    module.exports = {
        template: template   ,
		components:{
			lineChart
		},
		data(){
			return {
				"data_src" : "portfolio_appreciation",
				"data": [],
				"graphData": {}
			/*	"graphData":{ //sample
					barmode: "group",
//					"marginleft": 120,
					data: [{
						x: ['December', 'January', 'February','March','April'],
						y: [20, 14, 23,12,50],
						name: 'Cash',
						color: "#f6ac2f"
					},{
						x: ['December', 'January', 'February','March','April'],
						y: [12, 18, 29,34,98],
						name: 'Alternate Investment',
						color: "#2c3d4f"
					}]
				}*/
			}
		},
		watch:{
			"data":function(){
				this.createData()
			}
		},
		methods:{
			createData(){
				var labels=[];
				var corpus=[];
				var market=[];
				this.data.forEach((obj)=>{
						labels.push(obj.period);
						corpus.push(parseInt(obj.corpus_inMn))
						market.push(parseInt(obj.market_value_inMn))
				})
				var gdata={
					barmode: "group",
//					"marginleft": 120,
					data: [{
						x: labels,
						y: corpus,
						name: 'Corpus',
						color: "#f6ac2f"
					},{
						x: labels,
						y: market,
						name: 'Market Value',
						color: "#2c3d4f"
					}]
				}
				this.graphData=gdata;
			}
		
		},
		mounted(){

		}
		
    }
});

</script>