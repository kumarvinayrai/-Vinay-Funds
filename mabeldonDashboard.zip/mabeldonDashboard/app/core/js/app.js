"use strict";

define(['jquery','vue','vue-router','vue!/vue/mainApp.vue'], function($,Vue,Router,App) {

let vueApp=new Vue({
    el: "#vue-app",
    Router,
    components: {
     //   "main-dashboard": mainDashboard
       
    }
})

});

