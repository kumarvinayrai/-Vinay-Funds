<template>
        <section class="userlinked-accounts" v-if="data.length"> 
			<div class="row" v-for="account in data.slice(0, 3 )">
				<div class="col-sm-3 col-xs-2 padding-0 border-style text-center">
<!--					  <img class=" bank-img-style" src="app/core/img/boa.png" alt="">-->
						<span class="bankAccountType" :class="icons[account.account_type]"></span>
						<div class="fnt11 ">{{account.account_type}}</div>
				</div>
				<div class="col-sm-9 col-xs-10 ">
					<div class="text-warning fnt-14">{{account.bank}}</div>
					<small class="text-muted">
						  <p class="fnt-12 text-default lead fnt-14 disp-inline">Ac. No.</p>
						  <p class="fnt-12 fnt-Cblack disp-inline">{{account.account_number}}</p>
					</small>
					<div class="text-muted fnt18 "><span class="currency">{{account.currency}}</span> {{account.amount}}  </div>
			  	</div>
			  </div>
			
			<div class="viewMore"  v-if="data.length>3">
					<span class="pull-right ">
						<a href="#" class="btn_default text-primary lead fnt13" data-toggle="modal" data-target="#bankCustodyModal">View More..</a>
					</span>

					<!-- Modal -->
					<div class="modal fade" id="bankCustodyModal" tabindex="-1" role="dialog" aria-labelledby="myModalLabel" >
					  <div class="modal-dialog" role="document">
						<div class="modal-content">
						  <div class="modal-header">
							<button type="button" class="close" data-dismiss="modal" aria-label="Close"><span aria-hidden="true">&times;</span></button>
							<h4 class="modal-title" id="myModalLabel">Bank & Custody Accounts</h4>
						  </div>
						  <div class="modal-body">
							<div class="row" v-for="account in data">
								<div class="col-sm-2 col-xs-2 padding-0 border-style text-center">
										<span class="bankAccountType" :class="icons[account.account_type]"></span>
										<div class="fnt11 ">{{account.account_type}}</div>
								</div>
								<div class="col-sm-10 col-xs-10 ">
									<div class="text-warning fnt-14">{{account.bank}}</div>
									<small class="text-muted">
										  <p class="fnt-12 text-default lead fnt-14 disp-inline">Ac. No.</p>
										  <p class="fnt-12 fnt-Cblack disp-inline">{{account.account_number}}</p>
									</small>
									<div class="text-muted fnt18 "><span class="currency">{{account.currency}}</span> {{account.amount}}  </div>
								</div>
							  </div>
						  </div>
						  <div class="modal-footer">
							<button type="button" class="btn_default text-primary lead fnt13" data-dismiss="modal">Close</button>
						  </div>
						</div>
					  </div>
					</div>
    	
			</div>
		</section>
</template>

<script>
"use strict";
define(function (require, exports, module){
    module.exports = {
        template: template,
		data(){
			return {
				"data_src": "bank_custody_accounts",
				"data":[],
				"icons": {
					"Bank": "bank",
					"Custody": "custody",
					"Credit Card": "credit-card",
					"Loan": "loan",
					"Margin Account ": "margin-account",
				}
			}	
		},
		methods:{
		
		},
		mounted(){
 
		}
    }
});

</script>