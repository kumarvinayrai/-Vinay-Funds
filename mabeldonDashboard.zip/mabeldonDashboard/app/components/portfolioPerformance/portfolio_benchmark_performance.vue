<template>
    <div class="portfolioBenchmarkPerformance" v-if="Object.keys(data).length">
  		<barChart containerid="portfolioBenchmarkPerformanceGraph" :data_bucket="graphData"/>
    </div>    
</template>

<script>
"use strict";
define(function (require, exports, module){
	var barChart = require("vue!components/charts/bar_chart");

    module.exports = {
        template: template   ,
		components:{
			barChart
		},
		data(){
			return {
				"data_src" : "portfolio_vs_benchmark_performance",
				"data": {},
				"graphData": {}
/*				"graphData":{
					barmode: "group",
//					"marginleft": 120,
					data: [{
						x: ['December', 'January', 'February','March','April'],
						y: [20, 14, 23,12,50],
						name: 'Cash',
						orientation: 'v'
					},{
						x: ['December', 'January', 'February','March','April'],
						y: [12, 18, 29,34,98],
						name: 'Alternate Investment',
						orientation: 'v'
					},{
						x: ['December', 'January', 'February','March','April'],
						y: [12, 18, 29,34,98],
						name: 'Fixed Income',
						orientation: 'v'
					},{
						x: ['December', 'January', 'February','March','April'],
						y: [12, 98, 29,34,98],
					  	name: 'Equity',
						orientation: 'v'
					}]
				}*/
			}
		},
		watch:{
			"data": function(){
				this.createData();
			}
		},
		methods:{
			createData(){
				var gdata={
					barmode: "group",
					dataExtension: "%",
//					"marginleft": 120,
					data: [{
						x: this.data.period,
						y: this.data.portfolio_return,
						name: 'Portfolio',
						width: 0.5,
						color: "#f6ac2f",
						orientation: 'v'
					},{
						x: this.data.period,
						y: this.data.benchmark1_return,
						name: this.data.benchmark_names[0],
						width: 0.5,
						color: "#2c3d4f",
						orientation: 'v'
					},{
						x: this.data.period,
						y: this.data.benchmark2_return,
						name: this.data.benchmark_names[1],
						width: 0.5,
						color: "#55ace1",
						orientation: 'v'
					},{
						x: this.data.period,
						y: this.data.benchmark3_return,
					  	name:this.data.benchmark_names[2],
						width: 0.5,
						color: "#ef5030",
						orientation: 'v'
					}]
				};
				this.graphData=gdata;
			}
		},
		mounted(){

		}
		
    }
});

</script>