<template>
    <div class="assetAllocation" v-if="data.length">
  		<barChart containerid="sectorAllocationGraph" :data_bucket="graphData" />
    </div>    
</template>

<script>
"use strict";
define(function (require, exports, module){
	var barChart = require("vue!components/charts/bar_chart");

    module.exports = {
        template: template   ,
		components:{
			barChart
		},
		data(){
			return {
				"data_src" : "sector_allocation",
				"data": [],
				/*"graphData":{ //sample data
					barmode: "",
					"marginleft": 120,
					data: [{
						x: [26, 16, 15, 12, 9, 8, 6, 5, 3],
						y: ['Banking & finance', 'Oil & gas', 'Industrial','Auto','FMCG', 'IT', 'Pharmaceuticals', 'Media', 'Metal'],
						orientation: 'h'
					}]
				}
				*/
				"graphData":{}
			}
		},
		watch:{
			"data":function(){
				this.createData()
			}
		},
		methods:{
			createData(){
				var gdata=[{
					x: [],
					y: [],
					orientation: 'h'
				}];
				var labels=[];
				var values=[];
				this.data.forEach((obj)=>{
					gdata[0].y.push(obj.sector);
					gdata[0].x.push(parseInt(obj.allocation))
				})
				var gdata1={
					"barmode": "",
					"marginleft": 120,
				}
				gdata1.data=gdata;
				this.graphData=gdata1;
			}
		},
		mounted(){

		}
		
    }
});

</script>