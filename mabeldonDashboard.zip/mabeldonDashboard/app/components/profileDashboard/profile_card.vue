<template>
        <div id="customer_profile_card_data" class="customer_profile_card_wrp">
				<div class="card text-center" style="    padding-top: 30px;">
					<img :src="picture" />
						<h3 class="fnt-14">{{client_name}}</h3>
						<h4 class="blue-text lighten-3">RM: {{RM}}</h4>
						<div class="accountList text-center hide">
							<select class="form-control" v-model="selected_account" @change="changeAccount()">
								<option v-for="account in client_account_list" :value="account.number">{{account.name}}</option>
							</select>
							
						</div>
					
				</div>
		</div>
</template>

<script>
"use strict";
define(function (require, exports, module){
    module.exports = {
        template: template   ,
		data(){
			return {
				"data_src" : ["client_name", "RM"],
				"data": {},
				"RM": "",
				"client_id": "",
				"client_name": "",
				"client_account_list": [],
				"selected_account": "consolidated",
				"picture": ""
			}	
		},
		methods:{
			changeAccount(){
				this.$parent.selected_account=this.selected_account;	
			},
		},
		computed:{
			getClientName(){
				return this.$parent.client_name;
			}
		},
		mounted(){

		}
		
    }
});

</script>