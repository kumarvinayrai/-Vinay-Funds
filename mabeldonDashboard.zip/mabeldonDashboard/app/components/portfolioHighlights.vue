<template>
		<div class="portfolio-highlights-wrp" v-if="Object.keys(data).length">
				<div class="col-lg-3 col-md-3 col-xs-12 lft-padding ">
					<div class="cards card-bg-color1">
						<div class="media">
							<div class="media-left">
							 <span class="sprite card-icon1"></span>
							</div>
							<div class="media-body">
								<div class="card-title">INVESTMENT VALUE</div>
								<div class="card-value">{{data.Investment_Value}}</div>
							</div>
						</div>
					</div>
				</div>
				<div class="col-lg-3 col-md-3 col-xs-12 lft-padding ">
					<div class="cards card-bg-color2">
						<div class="media">
							<div class="media-left">
									<span class="sprite card-icon2"></span> 
	
							</div>
							<div class="media-body">
								<div class="card-title">CAPITAL INVESTED</div>
								<div class="card-value">{{data.Capital_Invested}}</div>
							</div>
						</div>
					</div>
				</div>
				<div class="col-lg-3 col-md-3 col-xs-12 lft-padding ">
					<div class="cards card-bg-color3">
						<div class="media">
							<div class="media-left">
									<span class="sprite card-icon3"></span>  </div>
							<div class="media-body">
								<div class="card-title">INCOME</div>
								<div class="card-value">{{data.Income}}</div>
							</div>
						</div>
					</div>
				</div>
				<div class="col-lg-3 col-md-3 col-xs-12 lft-padding ">
					<div class="cards card-bg-color4">
						<div class="media">
							<div class="media-left">
									<span class="sprite card-icon4"></span> 
							 </div>
							<div class="media-body">
								<div class="card-title">EXPENSES</div>
								<div class="card-value">{{data.Expenses}}</div>
							</div>
						</div>
					</div>
				</div>
				<div class="col-lg-6 col-md-6 col-xs-12  lft-padding ">
					<div class="cards card-bg-color5">
						<div class="media">
							<div class="media-left">
									<span class="sprite card-icon5"></span> 
							</div>
							<div class="media-body">
								<div class="container-fluid">
									<div class="row">
										<div class=" col-lg-3 col-md-3 col-sm-3 col-xs-3">
											<div class="card-title"><span class="xs-fnt-text">MTD</span></div>
											<div class="card-value"><span class="">{{data.MTD}}</span></div>
										</div>  
										<div class=" col-lg-3 col-md-3 col-sm-3 col-xs-3">
											<div class="card-title"><span class="xs-fnt-text">QTD</span></div>
											<div class="card-value"><span class="">{{data.QTD}}</span></div>
										</div>
										<div class=" col-lg-2 col-md-2 col-sm-2 col-xs-3">
											<div class="card-title"><span class="xs-fnt-text">YTD</span></div>
											<div class="card-value"><span class="">{{data.YTD}}</span></div>
										</div>
										<div class=" col-lg-4 col-md-4 col-sm-6 col-xs-3">
											<div class="card-title"><span class="xs-fnt-text">SINCE INCEPTION</span></div>
											<div class="card-value"><span class="">{{data.Since_Inception}}</span></div>
										</div>
										
									</div>    
								</div>
							</div>
						</div>
					</div>
			</div>
				<div class="col-lg-6 col-md-6 col-xs-12  lft-padding ">
					<div class="cards extraHigh">
						<div class="media">
							<div class="media-left">
									<span class="sprite card-icon6"></span> 
							</div>
							<div class="media-body">
								<div class="container-fluid">
									<div class="row">
										<div class=" col-lg-6 col-md-6 col-sm-6 col-xs-3">
											<div class="card-title"><span class="xs-fnt-text">INVESTIBLE CASH</span></div>
											<div class="card-value"><span class=" ">{{data.Investible_Cash}}</span></div>
										</div>  
										<div class=" col-lg-6 col-md-6 col-sm-6 col-xs-3">
											<div class="card-title"><span class="xs-fnt-text">DRAWING POWER</span></div>
											<div class="card-value"><span class=" ">{{data.Withdrawable_Limit}}</span></div>
										</div>
										
										
									</div>    
								</div>
							</div>
						</div>
					</div>
				</div>
	
			
		</div>
</template>

<script>
"use strict";
define(function (require, exports, module){
    module.exports = {
        template: template,        
        mounted(){
        },
		props: ["data"]
		,data:function() {
            return {
			
            }
		}  
		,methods:{          
			
	}
}
});

</script>