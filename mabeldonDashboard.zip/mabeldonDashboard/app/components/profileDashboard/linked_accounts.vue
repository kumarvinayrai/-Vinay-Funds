<template>
	<section class="linkedAcc">
		<div class="row padding5" v-for="account in data.slice(0, 3 )">
			<div class="col-sm-9">
				<div class="text-muted fnt-14" :title="account.account_name">{{account.account_name | truncate}} </div>
				<span class="text-warning fnt18 "><span class="currency">{{account.account_reporting_currency}}</span> {{account.account_value}} </span>
			</div>

			<div class="col-sm-3 text-right">
			   <label class="label label-primary">{{account.account_type}}</label>
				<br>
				<div class="text-danger mt-5">{{account.client_risk_profile}}</div>

			</div> 
		</div>
		
		<div class="viewMore" v-if="data.length>3">
				<span class="pull-right " >
					<a href="#" class="btn_default text-primary lead fnt13" data-toggle="modal" data-target="#linkedAccountsModal">View More..</a>
				</span>

					<!-- Modal -->
				<div class="modal fade" id="linkedAccountsModal" tabindex="-1" role="dialog" aria-labelledby="myModalLabel" >
				  <div class="modal-dialog" role="document">
					<div class="modal-content">
					  <div class="modal-header">
						<button type="button" class="close" data-dismiss="modal" aria-label="Close"><span aria-hidden="true">&times;</span></button>
						<h4 class="modal-title" id="myModalLabel">Linked Accounts</h4>
					  </div>
					  <div class="modal-body">
						  <div class="row padding5" v-for="account in data">
							<div class="col-sm-6">
								<div class="text-muted fnt-14">{{account.account_name}} </div>
								<span class="text-primary fnt18 lead"><span class="currency">{{account.account_reporting_currency}}</span> {{account.account_value}} </span>
							</div>

							<div class="col-sm-6 text-right">
							   <label class="label label-primary">{{account.account_type}}</label>
								<br>
								<div class="text-danger mt-5">{{account.client_risk_profile}}</div>

							</div> 
						</div>

					  </div>
					  <div class="modal-footer">
						<button type="button" class="btn_default text-primary lead fnt13" data-dismiss="modal">Close</button>
					  </div>
					</div>
				  </div>
				</div>

		</div>

	</section>
</template>

<script>
"use strict";
define(function (require, exports, module){
	var Vue= require("Vue");
/*	Vue.filter('truncate', function (text, stop, clamp) {
	return text.slice(0, stop) + (stop < text.length ? clamp || '...' : '')
})*/
    module.exports = {
        template: template   ,
		data(){
			return {
				"data_src" : "linked_accounts",
				"data": []
			}	
		},
		filters:{
			truncate: function (text) {
				var stop=25;
				var clamp="";
				return text.slice(0, stop) + (stop < text.length ? clamp || '...' : '')
			}
		},
		methods:{
		
		},
		computed:{
		},
		mounted(){

		}
		
    }
});

</script>