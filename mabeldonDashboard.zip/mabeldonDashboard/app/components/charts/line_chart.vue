<template>
    <div class="graphContainer">
		 <div :id="containerid" ><!-- Plotly chart will be drawn inside this DIV --></div>
    </div>    
</template>

<script>
"use strict";
define(function (require, exports, module){
	var Plotly=require("plotly");
    module.exports = {
        template: template   ,
		data(){
			return {
				
			}
		},
		props:["containerid","data_bucket"],
		watch:{
			"data_bucket"(){
				this.drawGraph();
			}	
		},
		methods:{
			drawGraph(){
				var data=[];
				this.data_bucket.data.forEach(dataObj =>{
					var d={
						  type: 'scatter',
						  x: [],
						  y: [],
						  name:'',
						  marker: {
							color: ''
						  },
						};
					d.x=dataObj.x;
					d.y=dataObj.y;
					d.name=dataObj.name;
					d.marker.color=dataObj.color;

					data.push(d);
				})
				
				var layout = {
					height: 320,
					margin: {
						l: 50,
						r: 50,
						b: 10,
						t: 10,
						pad: 0
					  },
					showlegend: true,
					legend: {"orientation": "h"}
				};

				Plotly.newPlot(this.containerid, data, layout, {displayModeBar: false});
			}
		},
		mounted(){
			this.drawGraph();
		}
		
    }
});

</script>