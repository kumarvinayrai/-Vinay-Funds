<template>
	<section class="investmentRecommendation" style="position: relative;">
		<div class="mainVerticalLine"></div>
		<div class="containAsset" v-for="(asset,indexAsset) in assets">
			<div class="panel-heading xs-panel-heading">
				<div class="panel-title">
					<div class="text-uppercase text-primary media-left">
						<a href="javascript:void(0)" type="button" class="text-uppercase assetName expandLink" :class="[indexAsset==0 ? 'firstAcc' : '']" data-toggle="collapse" :data-target="'#asset'+indexAsset" aria-expanded="false" :aria-controls="'asset'+indexAsset">
							<span class="ico" >
								<i class="indicator btn-primary glyphicon glyphicon-minus " style="font-family: 'Arial';" ></i>
								<i class="indicator btn-primary glyphicon  glyphicon-plus  " style="font-family: 'Arial';" ></i>
							</span>
							{{asset}}
						</a>

					</div>
					<div class="lable-contaier media-right">
						<div class="col-xs-12">
							<span class="label label-body label-primary pull-right">
								<span class="equity-lable"> Holding Cost&nbsp;$1500 </span>
								<span class="equity-lable"> Return&nbsp;$2500 </span>
								<span class="equity-lable"> Unrealized Gain Loss&nbsp;$5000 </span>
							</span>
						</div>

					</div>
				</div>

			</div>
			<div  class="collapse assetContainer" :class="[indexAsset==0 ? 'in' : '']" :id="'asset'+indexAsset">
				<div class="mainVerticalLine"></div>
				<div id="accordion" v-for="(secSub,indexSec) in getSectorSubAsset(asset)"  class="panel-group ">
					<div class="panel-heading">
						<h4 class="panel-title text-warning">
							<a data-toggle="collapse" class="text-uppercase sectorLink expandLink " :class="[indexSec==0 ? 'firstAcc' : '']" data-parent="#accordion" :href="'#sector-'+indexAsset+'-'+indexSec" aria-expanded="true">
								<span class="ico" >
									<i class="indicator btn-warning glyphicon glyphicon-minus " style="font-family: 'Arial';" ></i>
									<i class="indicator btn-warning glyphicon  glyphicon-plus  " style="font-family: 'Arial';" ></i>
								</span>
								{{secSub}}
							</a>
							<span class="label label-body label-warning " style="margin-left: 10px">
								<span class="equity-lable"> Holding Cost&nbsp;$1500 </span>
								<span class="equity-lable"> Return&nbsp;$2500 </span>
								<span class="equity-lable"> Unrealized Gain Loss&nbsp;$5000 </span>
							</span>
						</h4>
					</div>
					<div :id="'sector-'+indexAsset+'-'+indexSec" class="panel-collapse collapse sectorContainer" :class="[indexSec==0 ? 'in' : '']" aria-expanded="true" style="">
						<div class="mainVerticalLine"></div>

						<div class="panel-body">
						<!-- inner accardian-->
							<div class="panel-group" id="inner-accordion">
								<div class="panel panel-default panel-default-border " v-for="(security,indexSecurity) in filteredData[asset][secSub]">
									<div class="panel-heading">
										<h4 class="panel-title panel-title-padding title-padding">
											<a class="accordion-toggle custom-glyphicons firstAcc security_name" :class="[(getAccounts(security.security_name)).length ? 'triggerBlue' : '']"  data-toggle="collapse" data-parent="#inner-accordion" :href="'#innercollapse'+indexAsset+indexSec+indexSecurity" aria-expanded="false">
												<span class="ico" >
													<i class="indicator btn-primary glyphicon glyphicon-minus " style="font-family: 'Arial';" ></i>
													<i class="indicator btn-primary glyphicon  glyphicon-plus  " style="font-family: 'Arial';" ></i>
												</span>
												<span class="text-uppercase text-primary">{{security.security_name}}</span>
											</a>
										</h4> 
										<div class="row bgGrey">
												<div class="card-data-contaner col-xs-12 col-sm-6 col-md-6 padding-none col-lg-2 sm-border-bottom sm-border-right xs-border xs-border-bottom border-left" style="border-right: 0;">
													 <div class="">
														  <div class="row  border-bottom">
															  <div class="col-xs-12 col-sm-12 padding-none xstext-alignleft text-left">
																<span class="txt-pink-color">Security Currency</span>
															  </div>

														  </div> 
														  <div class="row  ">
																<div class="col-xs-12 col-sm-12 padding-none col-lg-12">
																	<div class="text-uppercase text-primary">cost</div>
																</div>
																<div class="col-xs-7	 col-sm-6 padding-none col-lg-6">
																	<span class="text-muted">Cost</span>
																</div>
																<div class="col-xs-5 col-sm-6 padding-none col-lg-6 text-right">
																  <span class="text-muted">Book Value</span>
																</div> 
																<div class="col-xs-6 col-sm-6 col-lg-6 padding-none ">
																	<span class="text-primary">{{security.scy}} {{security.average_cost_per_unit_scy}}</span>
																</div>
																<div class="col-xs-6 col-sm-6 col-lg-6 padding-none text-right">
																	<span class="text-primary">{{security.scy}} {{security.book_value_scy}}</span>
																</div>    

														 </div>

													 </div>  <!-- End row -->
												</div><!-- End container -->

												<div class="card-data-contaner col-xs-12 col-sm-6 padding-none col-md-6 col-lg-3 border-left-md sm-border-bottom xs-border border-left-0 xs-border-bottom ">
													<div class="">
														<div class="row  border-bottom">
															 <div class="col-xs-12 col-sm-12 padding-none xstext-alignleft text-right">
																<span class="text-muted">Unrealized Gain Loss</span>
																<span class=" text-primary unrealized-gainloss">{{security.scy}} {{security.unrealized_gain_loss_scy}}</span>
															 </div>
														</div> 
														<div class="row  bgcolor-market-value-card">
															<div class="col-xs-12 col-sm-12 padding-none col-lg-12">
															   <div class="text-uppercase text-primary">market value</div>
															</div>
															<div class="col-xs-6 padding-none col-sm-6 col-lg-6">
																 <span class="text-muted">Current Price</span>
															 </div>
															 <div class="col-xs-6 padding-none col-sm-6 col-lg-6 text-right">
																 <span class="text-muted">Market Value</span>
															 </div> 
															 <div class="col-xs-6 col-sm-6 padding-none col-lg-6">
															   <span class="text-primary">{{security.scy}} {{security.current_price_per_unit_scy}}</span>
															 </div>
															 <div class="col-xs-6 col-sm-6 padding-none col-lg-6 text-right">
															   <span class="text-primary">{{security.scy}} {{security.holding_value_scy}}</span>
															 </div>    

														</div>

													</div>  <!-- End row -->
												</div><!-- End container -->

												<div class="card-data-contaner col-xs-12 col-sm-6 padding-none col-md-6 col-lg-4 sm-border-right xs-border xs-border-bottom">

													<div class=" ">
														<div class="row border-bottom custom-row">
															<div class="col-xs-12 col-sm-5 col-lg-5 padding-none xstext-alignleft text-left">
																<span class="">Portfolio Currency</span>
															</div>
															  <div class="col-xs-12 col-sm-7 col-lg-7 padding-none xstext-alignleft text-right">
																  <span class="text-muted">Unrealized Gain Loss</span>
																  <span class=" text-primary unrealized-gainloss">{{security.pcy}} {{security.unrealized_gain_loss_pcy}}</span>
															  </div>
														</div>
														<div class="row custom-row border-bottom-md">
															<div class="col-xs-12 col-sm-12 col-lg-12 padding-none ">
																<div class="text-uppercase text-primary">market value</div>
															</div>
															<div class="col-xs-6 col-sm-6 col-lg-6 padding-none ">
																<span class="text-muted">CurrentPrice</span>
															</div>
															<div class="col-xs-6 col-sm-6 col-lg-6 padding-none text-right">
																<span class="text-muted">Holding Value</span>
															</div> 
															<div class="col-xs-6 col-sm-6 col-lg-6 padding-none">
																<span class="text-primary">{{security.pcy}} {{security.current_price_per_unit_pcy}}</span>
															</div>
															<div class="col-xs-6 col-sm-6 col-lg-6 text-right padding-none">
																<span class="text-primary">{{security.pcy}} {{security.holding_value_pcy}}</span>
															</div> 
														</div>


													</div>  <!-- End row -->

												</div><!-- End container -->

												<div class="card-data-contaner col-xs-12 col-sm-6 col-md-6 col-lg-3 border-left-md padding-none xs-border xs-border-bottom">

													  <div class=" ">
														  <div class="row border-bottom">
															  <div class="col-xs-12 col-sm-12 col-lg-12 padding-none xstext-alignleft text-right" style="margin-bottom: -21px;">

																  <a href="#" class="sprite-cons buy-icon"> 

																  </a> 
																  <a href="#" class="sprite-cons sale-icon">
																   </a>

															  </div>
														  </div>
													  <div class="row  border-bottom-md  xs-solid-border-bottom">
															<div class="col-xs-12 col-sm-12 col-lg-12 padding-none">
																	<div class="text-uppercase text-left text-primary">Security Details</div>
															</div>
															<div class="col-xs-4 col-sm-4 col-lg-4 padding-none">
																<span class="text-muted">Units</span>
															</div>
															<div class="padding-none col-xs-4 col-sm-4 col-lg-4">
																<span class="text-muted">Returns(%)</span>
															</div>
															<div class="padding-none col-xs-4 col-sm-4 col-lg-4  text-right">
																<span class="text-muted">Maturity Date</span>
															</div>
															<div class="padding-none col-xs-4 col-sm-4 col-lg-4">
																<span class="text-primary">{{security.units}}</span>
															</div>
															<div class="padding-none col-xs-4 col-sm-4 col-lg-4">
																<span class="text-primary">{{security.return}}</span>
															</div>
															<div class="padding-none col-xs-4 col-sm-4 col-lg-4 text-right">
																<span class="text-primary">{{security.maturity_date || '-'}}</span>
															</div>
													  </div>
												</div>  <!-- End row -->
										  </div><!-- End container -->
										</div>
										<div class="row border">
											<div class="col-lg-12">
												<div :id="'innercollapse'+indexAsset+indexSec+indexSecurity" class="panel-collapse collapse" aria-expanded="false" style="height: 0px;" >

													<div class="">
														<div class=" ">
															<div class="row accardian-data-container" v-for="account in getAccounts(security.security_name)">
																<div class="padding-none col-xs-12 col-sm-12 col-md-12 col-lg-12"><span>{{account.account_name}}</span></div>
																<div class="padding-none col-xs-4 col-sm-3 col-md-2 col-lg-2">
																	<div class="text-muted txt-field">Transaction Type</div> 
																	<div class="text-uppercase txt-data" :class="account.transaction_type"> {{account.transaction_type}}</div>
																</div>
																<div class="padding-none col-xs-4 col-sm-3 col-md-1 col-lg-1">
																	<div class="text-muted txt-field">Units</div>
																	<div class="text-primary txt-data">{{account.units}}</div>
																</div>
																<div class="padding-none col-xs-4 col-sm-3 col-md-2 col-lg-2">
																	<div class="text-muted txt-field">Cost(Per Unit)</div>
																	<div class="text-primary txt-data">{{account.scy}} {{account.average_cost_per_unit_scy}}</div>
																</div>
																<div class="padding-none col-xs-4 col-sm-3 col-md-2 col-lg-2">
																	<div class="text-muted txt-field">Total Amount</div>
																	<div class="text-primary txt-data">{{account.scy}} {{account.book_value_scy}}</div>
																</div>
																<div class="padding-none col-xs-4 col-sm-3 col-md-1 col-lg-1">
																	<div class="text-muted txt-field">TradeDate</div>
																	<div class="text-primary txt-data">{{account.trade_date}}</div>
																</div>
																<div class="padding-none col-xs-4 col-sm-3 col-md-2 col-lg-2">
																	<div class="text-muted txt-field">Settlement Date</div>
																	<div class="text-primary txt-data">{{account.settlement_date}}</div>
																</div>
																<div class="padding-none col-xs-4 col-sm-3 col-md-2 col-lg-2" v-if="account.transaction_type.toUpperCase()!='BUY'">
																	<div class="text-muted txt-field">Realized Gain/Loss</div>
																	<div class="text-primary txt-data">{{account.pcy}} {{account.realized_gain_loss_pcy}}</div>
																</div>

															</div>

														</div>

													</div>

												</div>

											</div>
										</div>
									</div>

								</div>

							</div>
						<!-- end inner accardian -->
						</div>
					</div>
				</div>

			</div>
		</div>

	</section>
</template>

<script>
"use strict";
define(function (require, exports, module){
	var Vue= require("Vue");

    module.exports = {
        template: template   ,
		data(){
			return {
				"data_src" : ["holding","transaction"],
				"data": {},
				"assets":[],
				"filteredData": {}
			}	
		},
		watch:{
			"data": function(){
				this.createData();
			}
		},
		methods:{
			createData(){
				var assetClasses=[];
				var filtered={};
				this.data.holding.forEach((obj)=>{
					var asset=obj.asset_class.trim();
					if(!assetClasses.includes(asset)){
						assetClasses.push(asset);
						filtered[asset]={};
					}
					if(asset.toUpperCase()==="EQUITY"){
						if(!Object.keys(filtered[asset]).includes(obj.sector)){
							filtered[asset][obj.sector]=[];
						}
						filtered[asset][obj.sector].push(obj);
					}
					else{
						if(!Object.keys(filtered[asset]).includes(obj.sub_asset_class)){
							filtered[asset][obj.sub_asset_class]=[];
						}
						filtered[asset][obj.sub_asset_class].push(obj);
					}
					
					
				})
				this.assets=assetClasses;
				console.log(filtered, "filtered", assetClasses);
				this.filteredData=filtered;
				
				
				
		
			},
			getSectorSubAsset(asset){
				return Object.keys(this.filteredData[asset]);
			},
			getAccounts(security_name){
				var acc=[];
				this.data.transaction.forEach((trans)=>{
					if(trans.security_name==security_name)
						acc.push(trans);
					
				})
				
				console.log(security_name,"===",acc)
					return acc;
			}

		
		},
		computed:{
		}, 
		mounted(){
			setTimeout(function(){
				$("body").find(".firstAcc").addClass("collapsed")
				
			},1000);

			$("body").on("click","a.triggerBlue",function(){
				
			
				if($(this).parent().next().hasClass("bgBlue")){
					$(this).parent().next().removeClass("bgBlue");
				}
				else{
//					$(".bgBlue").removeClass("bgBlue");
					$(this).parent().next().toggleClass("bgBlue");
				}
			})
		}
		
    }
});

</script>