<template>
		<div>
			<div class="containSearch">
				<input class="form-control" placeholder="Search client..." v-model="searchValue" id="search" type="text" />
				<button class="btn btn-warning" @click="changeCustomer"><i class="fa fa-search"></i></button>
			</div>
			<div class="container-fluid">
				<div class="card">
					<div class="row bgNavy" >
						<div class="col-lg-3 col-md-3 lft-padding">
							<profileCard ref="clientDetail" />
						</div>
						<div class="col-lg-9 col-md-9 lft-padding">
							<portfolio-highlights :data="portfolio_highlights"/>
							
						</div>
					</div>
					
<!--					<client-detail ref="clientDetail" ></client-detail>-->
					<div class="selectAccount">
						<button v-for="acc in accList" class="btn " :class="[acc.number==selected_account? 'btn-primary' : 'btn-default']" @click="changeAcc(acc.number)">{{acc.name}}</button>
					</div>
					<main-nav></main-nav>
					<div class="tabPane">
			<!--			<keep-alive>-->
						<router-view ref="dashTab" @change="change()"></router-view>
			<!--			</keep-alive>-->

					</div>
				</div>

			</div>
		</div>
</template>

<script>
"use strict";
define([
    'Vue',
    'vue-router',
	'axios',
    'vue!components/portfolioHighlights',
    'vue!components/nav',
    'vue!components/profileDashboard/profileDashboard',
    'vue!components/portfolioOverview/portfolioOverview',
    'vue!components/clientDetail',
    'vue!components/portfolioPerformance/portfolioPerformance',
    'vue!components/portfolioHoldings/portfolioHoldings',
	"vue!components/profileDashboard/profile_card"
  ], 
  function(
    Vue,
    VueRouter,
	axios,
    portfolioHighlights,
    Nav,
    profileDashboard, 
    portfolioOverview,
	clientDetail,
	portfolioPerformance,
	portfolioHoldings,
    profileCard	
  ){

//	var profileCard = require("vue!components/profileDashboard/profile_card");

  const routes = [
    { path: '/profileDashboard', component: profileDashboard},
    { path: '/portfolioOverview', component: portfolioOverview},
    { path: '/portfolioPerformance', component: portfolioPerformance},
    { path: '/portfolioHoldings', component: portfolioHoldings}
  ]
  const router = new VueRouter({
    routes 
  })

  Vue.use(VueRouter)

  return new Vue({
    template: template,
    router,
    components: {
        "portfolio-highlights": portfolioHighlights,
        "main-nav":Nav,
		"client-detail": clientDetail,
		profileCard
    },
    data: {
		"dashboardData":{},
		"searchValue": "",
		"customerName":"Aneesh Abraham",
		"portfolio_highlights":{},
		"selected_account": "consolidated",
		"accList":[]

    },
	  
  	watch:{
		"selected_account": function(){
			this.$refs.dashTab.selected_account= this.selected_account;
		}	
	},
	
    methods: {
		changeAcc(acc){
			this.selected_account=acc;
			this.$refs.dashTab.selected_account= this.selected_account;

		},
		changeCustomer(){
			this.customerName=this.searchValue;
			this.fetchData();
		},
		fetchData:function(){
			let _this=this;
			 axios
			  .get('/customer2?client_name='+this.customerName)
			  .then(response => {
				 _this.dashboardData=response.data[0];
				 _this.portfolio_highlights=_this.dashboardData.portfolio_highlights;
				 _this.selected_account="consolidated";
				 if(_this.$route.path!="/")
					 _this.callSetData();
				 _this.setClientDetailData();
				
			 })
		},
		callSetData(){
			/* Set or Reset particular data*/
			this.$refs.dashTab.selected_account= this.selected_account;
			this.$refs.dashTab.client_name= this.dashboardData.client_name;
			
			/* Call set function of child tab*/
			 this.$refs.dashTab.setData(this.dashboardData);
			 this.$refs.dashTab.client_account_list=Object.keys(this.dashboardData.client_accounts);
			 this.accList=this.dashboardData.client_account_list;
		},
		setClientDetailData(){
			this.$refs.clientDetail.client_id= this.dashboardData.client_id;
			this.$refs.clientDetail.RM= this.dashboardData.RM;
			this.$refs.clientDetail.picture= this.dashboardData.picture;
			this.$refs.clientDetail.client_name= this.dashboardData.client_name;
			this.$refs.clientDetail.client_account_list= this.dashboardData.client_account_list;
		}
    },
	  created(){
		  this.fetchData();

	  },
	  mounted(){
		 
	  }
  })
});
</script>

<style>
	.containSearch {
		width: 30%;
		position: absolute;
		top: 9px;
		right: 14px;
	}
	.containSearch button{
		top: 0;
		position: absolute;
		right: 0;
	}

	.card{
		    overflow: hidden;
	}
	
	.selectAccount{
		background: #e4e4e4;
		padding: 5px;
	}
	
	.selectAccount .btn{
		margin-right: 5px;
	}
	
	.selectAccount .btn-default{
		background: white;
/*		border: 2px solid #191950;*/
		color: #191950;
	}
	
</style>