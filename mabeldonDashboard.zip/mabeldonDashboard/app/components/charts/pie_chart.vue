<template>
    <div class="graphContainer">
		 <div :id="containerid" ><!-- Plotly chart will be drawn inside this DIV --></div>
    </div>    
</template>

<script>
"use strict";
define(function (require, exports, module){
	var Plotly=require("plotly");
    module.exports = {
        template: template   ,
		data(){
			return {
//				data_bucket: {}
			}
		},
		watch:{
			"data_bucket": function(){
				this.drawGraph();
			}	
		},
		updated:function(){
			this.drawGraph();

		},
		props:["containerid","data_bucket"],
		methods:{
			drawGraph(){
				/* set values*/
				var values=this.data_bucket.values;
				var labels=this.data_bucket.labels;
				
				/* creating labels */	
				var text=[];
				for(let i=0;i< values.length;i++){
					text.push("<span style='font-size:10px'>"+ labels[i] + "</span><br><b  style='font-size:14px'>"+ values[i] + " %</b>");
				}
				var data = [{
				  values,
				  labels,
				  text,
				  textinfo: 'text',
				  type: 'pie',
				  hole: .8,
				  hoverinfo: 'label+percent',
				 'marker': {
				  'colors': [
					'#69f8c3',
					'#ef5030',
					'#55addf',
					'#2c3d4f',
					'#f6ac2f',
					'#5fab9e',
					'#fe9456',
					'#fdf264'
				  ]
				}
				}];

				var layout = {
				showlegend: false,
				legend: {"orientation": "h"},

				height: 300,
				  margin: {
					l: 50,
					r: 50,
					b: 50,
					t: 50,
					pad: 4
				  }
				};

				Plotly.newPlot(this.containerid, data, layout,  {displayModeBar: false});

			}
		},
		mounted(){
			this.drawGraph();
		}
		
    }
});

</script>