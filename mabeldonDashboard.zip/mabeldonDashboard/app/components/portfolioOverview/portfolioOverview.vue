<template>
		<section class="portfolioHighlights">
			<div class="row">
				<div class="col col-lg-12 col-sm-12">
					<div class="card" style="min-height:auto;">
						<h2 class="mcard-head mcard-header" style="background: #191950">Change in Portfolio Value</h2>
						<div class="mcard-body"><change-in-portfolio-value/></div>
					</div>
				</div>
			</div>
			<div class="row">
				<div class="col col-lg-4 col-md-4">
					<div class="card">
						<h2 class="mcard-head">Asset Allocation </h2>
						<div class="mcard-body" id="assetAllocation"><asset-allocation/></div>
					</div>
				</div>
				<div class="col col-lg-8 col-md-8">
					<div class="card">
						<h2 class="mcard-head">Allocation Movement </h2>
						<div class="mcard-body" id="allocationMovement"><allocationMovement/></div>
					</div>
				</div>
				
				<div class="col col-lg-4 col-md-4">
					<div class="card">
						<h2 class="mcard-head">Sub Asset Allocation </h2>
						<div class="mcard-body" id="subAssetAllocation"><subAssetAllocation/></div>
					</div>
				</div>
				<div class="col col-lg-8 col-md-8">
					<div class="card">
						<h2 class="mcard-head">Sector Allocation </h2>
						<div class="mcard-body" id="sectorAllocation"><sectorAllocation/></div>
					</div>
				</div>
				<div class="col col-lg-4 col-md-4">
					<div class="card">
						<h2 class="mcard-head">Top 5 Holdings</h2>
						<div class="mcard-body" id="topHolding"><topHolding/></div>
					</div>
				</div>
				<div class="col col-lg-8 col-md-8">
					<div class="card">
						<h2 class="mcard-head">Recommended v/s Actual Asset Allocation </h2>
						<div class="mcard-body" id="recommendedActualAllocation"><recommendedActualAllocation/></div>
					</div>
				</div>
			
				
			</div>
		</section>
</template>

<script>
"use strict";
define(function (require, exports, module){
	var change_in_portfolio_value = require("vue!components/portfolioOverview/change_in_portfolio_value");
	var asset_allocation = require("vue!components/portfolioOverview/asset_allocation");
	var subAssetAllocation = require("vue!components/portfolioOverview/sub_asset_allocation");
	var sectorAllocation = require("vue!components/portfolioOverview/sector_allocation");
	var allocationMovement = require("vue!components/portfolioOverview/allocation_movement");
	var recommendedActualAllocation = require("vue!components/portfolioOverview/recommended_actual_allocation");
	var topHolding = require("vue!components/portfolioOverview/top_holding");

    module.exports = {
        template: template,    
		components:{
			"change-in-portfolio-value":change_in_portfolio_value,
			"asset-allocation":asset_allocation,
			subAssetAllocation,
			sectorAllocation,
			allocationMovement,
			recommendedActualAllocation,
			topHolding
		},
		data(){
			return {
				"data_source":[],
				"tabData":{},
				"selected_account": "",
				"client_account_list":["consolidated"],
				"client_name": ""
			}
		},
         computed: {
            username () {
                return this.$route.params.username
            }
        },
		watch:{
			"selected_account": function(){
				this.setData(this.$parent.dashboardData);
			}	
		},
            methods: {
			
			setData(data){
				let _this=this;
				
				let dataKeys=Object.keys(data);
				this.$children.forEach((child)=>{
					let dataSrc=child.data_src;
					if(dataSrc.constructor===Array){
						var d={}
					   	dataSrc.forEach((dsrc)=>{
							d[dsrc]=data[dsrc];
						})
						child.data=d;
				   }
					else 
					if(dataKeys.includes(dataSrc)){
						child.data=data[dataSrc];
					}
					else{
						
						child.data=data.client_accounts[_this.selected_account][dataSrc];
								
					}

				})
			},
			change(){
				this.setData(this.$parent.dashboardData)	
			},
            goBack () {
                window.history.length > 1
                ? this.$router.go(-1)
                : this.$router.push('/')
            }
        },
		mounted(){
			if(Object.keys(this.$parent.dashboardData).length)
				this.$parent.callSetData();

		}
    }
});

</script>