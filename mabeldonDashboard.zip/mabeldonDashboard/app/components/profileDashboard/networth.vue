<template>
	<section class="networth">
		<div class=""><strong class="text-muted fnt-14">Assets</strong></div>
		<div class="row">
			<div class="col-lg-6 col-md-6 col-xs-6 text-muted">Investment Portfolio</div>
			<div class="col-lg-6 col-md-6 col-xs-6 text-right"> {{data.investment_portfolio}}</div>
		</div>
		<div class="row">
			<div class="col-lg-6 col-md-6 col-xs-6 text-muted">Held Away Investments </div>
			<div class="col-lg-6 col-md-6 col-xs-6 text-right"> {{data.held_away_investments}}</div>
		</div>
		<div class="row">
			<div class="col-lg-6 col-md-6 col-xs-6 text-muted">Cash & Deposits  </div>
			<div class="col-lg-6 col-md-6 col-xs-6 text-right"> {{data.cash_deposits}}</div>
		</div>
		<div class="row no-border-bottom">
			<div class="col-lg-12 col-md-12 col-xs-12 text-right fnt-14 text-warning"> {{data.total_assets}}</div>
		</div>
		
		
		<div class=""><strong class="text-muted fnt-14">Liabilities</strong></div>
		<div class="row">
			<div class="col-lg-6 col-md-6 col-xs-6 text-muted">Home Loan </div>
			<div class="col-lg-6 col-md-6 col-xs-6 text-right"> {{data.home_loan}}</div>
		</div>
		<div class="row ">
			<div class="col-lg-6 col-md-6 col-xs-6 text-muted">Vehicle Loan</div>
			<div class="col-lg-6 col-md-6 col-xs-6 text-right"> {{data.vehicle_loan}}</div>
		</div>
			
		<div class="row">
			<div class="col-lg-6 col-md-6 col-xs-6 text-muted">Credit Card Outstanding</div>
			<div class="col-lg-6 col-md-6 col-xs-6 text-right"> {{data.credit_card_outstanding}}</div>
		</div>		
		<div class="row">
			<div class="col-lg-6 col-md-6 col-xs-6 text-muted">Margin Account</div>
			<div class="col-lg-6 col-md-6 col-xs-6 text-right"> {{data.margin_account}}</div>
		</div>
		<div class="row no-border-bottom">
			<div class="col-lg-12 col-md-12 col-xs-12 text-right fnt-14 text-warning"> - {{data.total_liability}}</div>
		</div>
		<div class="row no-border-bottom card-value">
			<div class="col-lg-6 col-md-6 col-xs-6 text-warning "><strong>Total Networth</strong></div>
			<div class="col-lg-6 col-md-6 col-xs-6 text-right text-warning "><strong> {{data.margin_account}}</strong></div>
		</div>

	</section>
</template>

<script>
"use strict";
define(function (require, exports, module){
	var Vue= require("Vue");

    module.exports = {
        template: template   ,
		data(){
			return {
				"data_src" : "networth",
				"data": {}
			}	
		},
		filters:{
			truncate: function (text) {
				var stop=25;
				var clamp="";
				return text.slice(0, stop) + (stop < text.length ? clamp || '...' : '')
			}
		},
		methods:{
		
		},
		computed:{
		},
		mounted(){

		}
		
    }
});

</script>