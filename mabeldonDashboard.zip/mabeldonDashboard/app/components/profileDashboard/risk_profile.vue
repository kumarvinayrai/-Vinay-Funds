<template>
	<gauge-chart id="riskProfileGraph" :data="data"></gauge-chart>
</template>

<script>
"use strict";
define(function (require, exports, module){
	var gauge = require("vue!components/charts/gauge");

    module.exports = {
        template: template   ,
		components: {
			"gauge-chart": gauge	
		},
		data(){
			return {
				"data_src" : "risk_profile",
 				"data": {}
			}	
		},
		methods:{
			
		},
		computed:{
		},
		mounted(){
		}
		
    }
});

</script>