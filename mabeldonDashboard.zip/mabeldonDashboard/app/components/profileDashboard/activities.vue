<template>
		<section class="opportunities">
		<div class="row" v-for="activity in data.slice(0,3)">
			<div class="col-sm-2 col-xs-2 border-style text-center">
				<span class="text-light">{{getDate(activity.due_date,"month")}}</span><br>
				<span class="text-muted fnt19">{{getDate(activity.due_date,"day")}} </span>
			</div>
			<div class="col-sm-10 col-xs-10 ">
				<div class="text-muted  fnt-14 text-warning ">{{activity.subject}}</div>
				<div class="fnt-14  " data-toggle="tooltip" :title="activity.remarks">{{activity.remarks | truncate}}<label class="label label-warning pull-right">{{activity.type}}</label></div>
			</div>
		</div>
		
		<div class="viewMore" v-if="data.length>3">
			<span class="pull-right">
				<a href="" class="btn btn_default text-primary lead fnt13" data-toggle="modal" data-target="#activitiesModal">View More..</a>
			</span>

			<!-- Modal -->
			<div class="modal fade" id="activitiesModal" tabindex="-1" role="dialog" aria-labelledby="myModalLabel">
			  <div class="modal-dialog" role="document">
				<div class="modal-content">
				  <div class="modal-header">
					<button type="button" class="close" data-dismiss="modal" aria-label="Close"><span aria-hidden="true">&times;</span></button>
					<h4 class="modal-title" id="myModalLabel">Opportunities Portfolio Alerts</h4>
				  </div>
				  <div class="modal-body">
					  <div class="row" v-for="activity in data">
						<div class="col-sm-2 col-xs-2 border-style text-center">
							<span class="text-light">{{getDate(activity.due_date,"month")}}</span><br>
							<span class="text-muted fnt19">{{getDate(activity.due_date,"day")}} </span>
						</div>
						<div class="col-sm-10 col-xs-10 ">
							<div class="text-muted  fnt-14 text-warning ">{{activity.subject}}</div>
							<div class="fnt-14  " >{{activity.remarks}}<label class="label label-warning pull-right">{{activity.type}}</label></div>
						</div>
					  </div>
				  </div>
				  <div class="modal-footer">
					<button type="button" class="btn btn_default text-primary fnt13" data-dismiss="modal">Close</button>
				  </div>
				</div>
			  </div>
			</div>

		</div>
		
	</section>
</template>

<script>
"use strict";
define(function (require, exports, module){

    module.exports = {
        template: template   ,
		data(){
			return {
				"data_src" : "activities",
				"data": []
			}	
		},
		filters:{
			truncate: function (text) {
				var stop=60;
				var clamp="";
				return text.slice(0, stop) + (stop < text.length ? clamp || '...' : '')
			}
		},
		methods:{
			getDate(date,part){
				var dateO=new Date(date);
				if(part=="day"){
					return dateO.getDate();
				}
				else{
					var months=["JAN", "FEB", "MAR", "APR", "MAY", "JUN","JUL", "AUG", "SEP", "OCT", "NOV", "DEC"];
					return months[dateO.getMonth()];
				}
			}
		},
		computed:{
		},
		mounted(){
			
			
		}
		
    }
});

</script>