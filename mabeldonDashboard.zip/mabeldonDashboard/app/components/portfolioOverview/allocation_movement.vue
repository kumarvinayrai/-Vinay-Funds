<template>
    <div class="allocationMovement" v-if="data.length">
  		<barChart containerid="allocationMovementGraph" :data_bucket="graphData" :data="data"/>
    </div>    
</template>

<script>
"use strict";
define(function (require, exports, module){
	var barChart = require("vue!components/charts/bar_chart");

    module.exports = {
        template: template   ,
		components:{
			barChart
		},
		data(){
			return {
				"data_src" : "asset_allocation_movement",
				"data": [],/*
				"graphData":{ //sample data
					barmode: "stack",
//					"marginleft": 120,
					data: [{
						x: ['December', 'January', 'February','March','April'],
						y: [20, 14, 23,12,50],
						name: 'Cash',
						color: "#f6ac2f",
						orientation: 'v'
					},{
						x: ['December', 'January', 'February','March','April'],
						y: [12, 18, 29,34,98],
						name: 'Alternate Investment',
						color: "#2c3d4f",
						orientation: 'v'
					}]
				}*/
				"graphData": {}
			}
		},
		watch:{
			"data": function(){
				this.createData();
			}
		}
		,
		methods:{
			createData(){
				var assetClasses=[];
				var period=[];
				var values=[];
				var filtered={};
				var d=[];
				this.data.forEach((obj)=>{
					if(!assetClasses.includes(obj.asset_classes)){
						assetClasses.push(obj.asset_classes);
						filtered[obj.asset_classes]=[];
					}
					filtered[obj.asset_classes].push(obj);
					if(!period.includes(obj.period)){
						period.push(obj.period);
					}
					
				})
				
				var emptyArray=[];
				period.forEach((p)=>{
					emptyArray.push(0);
				})
				assetClasses.forEach((asset)=>{
					var assetArray=emptyArray.slice();
					filtered[asset].forEach((filt)=>{
						period.forEach((ptime,index)=>{
							if(filt.period==ptime && filt.asset_classes==asset)
								assetArray[index]+=parseInt(filt.allocation)
						})
					})
					var jsonP={};
					jsonP.x=period;
					jsonP.y=assetArray;
					jsonP.name=asset;
					jsonP.orientation= 'v'
					d.push(jsonP);

				});

				var gdata={};
				gdata.barmode="stack";
				gdata.data=d;
				
				this.graphData=gdata;
			}
		
		},
		mounted(){

		}
		
    }
});

</script>