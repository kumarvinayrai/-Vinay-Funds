<template>
    <div class="topHolding" v-if="Object.keys(data).length">
		<div class="custom-panel row">             
			<div class="col-xs-12 col-sm-12 col-md-12 col-lg-12 text-primary">
				{{data.benchmark1_name}}

			</div> 
			<div class="col-xs-6 col-sm-6 col-md-6 col-lg-8 bg-badge">
				<div class="text-muted fnt18 ">{{data.benchmark1_value_currency}} {{data.benchmark1_value}} </div>
			</div>
			<div class="col-xs-6 col-sm-6 col-md-6 col-lg-4 text-right">
				<span class="">{{data.benchmark1_return}}%</span>&nbsp;
			</div> 
		</div> 
		
		<div class="custom-panel row">             
			<div class="col-xs-12 col-sm-12 col-md-12 col-lg-12 text-primary">
				{{data.benchmark2_name}}

			</div> 
			<div class="col-xs-6 col-sm-6 col-md-6 col-lg-8 bg-badge">
				<div class="text-muted fnt18 ">{{data.benchmark2_value_currency}} {{data.benchmark2_value}} </div>
			</div>
			<div class="col-xs-6 col-sm-6 col-md-6 col-lg-4 text-right">
				<span class="">{{data.benchmark2_return}}%</span>&nbsp;
			</div> 
		</div> 

		<div class="custom-panel row">             
			<div class="col-xs-12 col-sm-12 col-md-12 col-lg-12 text-primary">
				{{data.benchmark3_name}}

			</div> 
			<div class="col-xs-6 col-sm-6 col-md-6 col-lg-8 bg-badge">
				<div class="text-muted fnt18 ">{{data.benchmark3_value_currency}} {{data.benchmark3_value}} </div>
			</div>
			<div class="col-xs-6 col-sm-6 col-md-6 col-lg-4 text-right">
				<span class="">{{data.benchmark3_return}}%</span>&nbsp;
			</div> 
		</div> 

    </div>    
</template>

<script>
"use strict";
define(function (require, exports, module){

    module.exports = {
        template: template   ,
		components:{
		},
		data(){
			return {
				"data_src" : "portfolio_performance",
				"data": {}
			}
		},
		methods:{
		
		},
		mounted(){

		}
		
    }
});

</script>