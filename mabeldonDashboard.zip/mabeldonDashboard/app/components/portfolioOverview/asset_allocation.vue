<template>
    <div class="assetAllocation" v-if="data.length">
  		<pie-chart ref="pieChart" containerid="assetAllocationGraph" :data_bucket="graphData"></pie-chart>
    </div>    
</template>

<script>
"use strict";
define(function (require, exports, module){
	var pie_chart = require("vue!components/charts/pie_chart");
//	var pie_chart = require("vue!components/charts/dummy");

    module.exports = {
        template: template   ,
		components:{
			"pie-chart": pie_chart	
		},
		data(){
			return {
				"data_src" : "asset_and_product_allocation",
				"data": [],
				/*"graphData":{  //Sample data structure
					"values": [8, 28, 16, 27, 28],
					"labels": ['Cash', 'Equity', 'Mutual Funds', "Fixed Income", "Alternate Income"]
				}*/
				"graphData":{}
			}
		},
		watch:{
			"data": function(){
				this.createData();	

			}
		},
		
		methods:{
			createData(){

				var labels=[];
				var values=[];
				this.data.forEach((obj)=>{
					if(!labels.includes(obj.asset_classes)){
						labels.push(obj.asset_classes);
						values.push(parseInt(obj.allocation))

					}
					else{
						var ind=_.indexOf(labels,obj.asset_classes);
						values[ind]+=parseInt(obj.allocation)
					}
				})
				var gdata={
					values: values,
					labels: labels
				}
				this.graphData=gdata;

			}
		},
		mounted(){

		}
		
    }
});

</script>