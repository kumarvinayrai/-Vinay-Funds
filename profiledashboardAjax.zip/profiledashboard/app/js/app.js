$.ajax({
    url: "template/profile_dashboard.html",
    success: function(data) {
        $('#profile-dashboard').html(data);
        $.ajax({
            url: "template/customer_profile_card.html",
            success: function(data) {
                $('#customer_profile_card_data').html(data);
            }
        });
        $.ajax({
            url: "template/family_tree.html",
            success: function(data) {
                $('#family_tree_data').html(data);
            }
        });

        $.ajax({
            url: "template/portfolio_highlights.html",
            success: function(data) {
                $('#portfolio-highlights-data').html(data);
            }
        });
        $.ajax({
            url: "template/address_detail.html",
            success: function(data) {
                $('#address_detail_data').html(data);
            }
        });
        $.ajax({
            url: "template/linked_accounts.html",
            success: function(data) {
                $('#linked_accounts_data').html(data);
            }
        });

        $.ajax({
            url: "template/bank_custody_accounts.html",
            success: function(data) {
                $('#bank_custody_accounts_data').html(data);
            }
        });

        $.ajax({
            url: "template/opportunity.html",
            success: function(data) {
                $('#opportunity_data').html(data);
            }
        });
        $.ajax({
            url: "template/key_portfolio_alerts.html",
            success: function(data) {
                $('#key_portfolio_alerts_data').html(data);
            }
        });
        $.ajax({
            url: "template/risk_rofile.html",
            success: function(data) {
                $('#risk_rofile_data').html(data);

        
            }
        });

        var tpl = []

        $.ajax({
            url: "http://localhost:3000/Portfolio_Highlights",
            success: function(data) {
            //console.log(data)
            var tblRow = "<div>" +data.Investment_Value + "</div>"
            console.log(data)
        /*     $(tblRow).appendTo("div"); */
            }
        });

    
    }
});




