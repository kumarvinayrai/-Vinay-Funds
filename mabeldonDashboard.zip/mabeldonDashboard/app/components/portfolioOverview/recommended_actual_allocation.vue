<template>
    <div class="recommendedActualAllocation"  v-if="data.length">
  		<barChart containerid="recommendedActualAllocationGraph" :data_bucket="graphData"/>
    </div>    
</template>

<script>
"use strict";
define(function (require, exports, module){
	var barChart = require("vue!components/charts/bar_chart");

    module.exports = {
        template: template   ,
		components:{
			barChart
		},
		data(){
			return {
				"data_src" : "recommended_vs_actual",
				"data": [],
			/*	"graphData":{ //sample data
					barmode: "group",
//					"marginleft": 120,
					data: [{
						x: ['December', 'January', 'February','March','April'],
						y: [20, 14, 23,12,50],
						name: 'Cash',
						width: 0.5,
						color: "#ef5030",
						orientation: 'v'
					},{
						x: ['December', 'January', 'February','March','April'],
						y: [12, 18, 29,34,98],
						name: 'Alternate Investment',
						width: 0.5,
						color: "#55ace1",
						orientation: 'v'
					}]
				}
			*/
				"graphData": {}
			}
		},
		watch:{
			"data":function(){
				this.createData()
			}
		},
		methods:{
			createData(){
				var gdata={
					x: [],
					y: [],
					orientation: 'v'
				};
				var labels=[];
				var recommendedValues=[];
				var actualValues=[];
				this.data.forEach((obj)=>{
					labels.push(obj.asset_classes);
					recommendedValues.push(parseInt(obj.recommended_allocation))
					actualValues.push(parseInt(obj.actual_allocation))
				})
				
				var gdata1={
					"barmode": "group",
					"data": [
						{
							x: labels,
							y: recommendedValues,
							name: 'Recommended Values',
							orientation: 'v'
						},{
							x: labels,
							y: actualValues,
							name: 'Actual Values',
							orientation: 'v'
						}
					]
				}
			
				this.graphData=gdata1;
			}
		
		},
		mounted(){

		}
		
    }
});

</script>